import { addDays, addWeeks, addMonths, isSunday, setDay, setDate, format, isBefore, startOfDay } from "date-fns";

export type Frequency = "daily" | "weekly" | "monthly";

export interface Installment {
  number: number;
  dueDate: Date;
  amount: number;
  status: "pending" | "paid" | "overdue";
}

export function generateInstallments(
  amount: number,
  count: number,
  frequency: Frequency,
  startDate: Date,
  options: {
    includeSundays?: boolean;
    paymentDay?: number; // 0-6 for weekly, 1-31 for monthly
  }
): Installment[] {
  const installments: Installment[] = [];
  const installmentValue = amount / count;
  let currentDate = startOfDay(startDate);

  for (let i = 1; i <= count; i++) {
    if (frequency === "daily") {
      if (i > 1) {
        currentDate = addDays(currentDate, 1);
        if (!options.includeSundays && isSunday(currentDate)) {
          currentDate = addDays(currentDate, 1);
        }
      }
    } else if (frequency === "weekly") {
      currentDate = addWeeks(currentDate, 1);
    } else if (frequency === "monthly") {
      if (i === 1) {
        if (options.paymentDay !== undefined) {
          currentDate = setDate(currentDate, options.paymentDay);
          if (isBefore(currentDate, startOfDay(startDate))) {
            currentDate = addMonths(currentDate, 1);
          }
        }
      } else {
        currentDate = addMonths(currentDate, 1);
      }
    }

    installments.push({
      number: i,
      dueDate: new Date(currentDate),
      amount: installmentValue,
      status: "pending",
    });
  }

  return installments;
}

export function getWhatsAppMessage(loan: any, installments: any[]) {
  const paid = installments.filter(i => i.status === 'paid').reduce((s, i) => s + i.amount, 0);
  const pending = installments.filter(i => i.status !== 'paid').reduce((s, i) => s + i.amount, 0);
  const next = installments.find(i => i.status !== 'paid');

  const frequencyMap: any = { daily: "Diário", weekly: "Semanal", monthly: "Mensal" };

  return `Olá ${loan.clientName}, aqui está o resumo do seu empréstimo:

Valor total: R$ ${loan.totalAmount.toFixed(2)}
Forma de pagamento: ${frequencyMap[loan.frequency]}
Parcelas: ${loan.installmentsCount} de R$ ${loan.installmentValue.toFixed(2)}

Total pago: R$ ${paid.toFixed(2)}
Pendente: R$ ${pending.toFixed(2)}

Próximo vencimento: ${next ? format(new Date(next.dueDate), 'dd/MM/yyyy') : 'N/A'}

Qualquer dúvida estou à disposição.`;
}

export function getWhatsAppSummaryMessage(clientName: string, loan: any, installments: any[], period: 'daily' | 'weekly' | 'monthly' | 'all' = 'all') {
  const now = new Date();
  let filteredInsts = installments;
  
  if (period === 'daily') {
    const start = startOfDay(now);
    filteredInsts = installments.filter(i => {
      const d = new Date(i.dueDate);
      return d >= start && d <= now;
    });
  } else if (period === 'weekly') {
    const start = addDays(now, -7);
    filteredInsts = installments.filter(i => {
      const d = new Date(i.dueDate);
      return d >= start && d <= now;
    });
  } else if (period === 'monthly') {
    const start = addDays(now, -30);
    filteredInsts = installments.filter(i => {
      const d = new Date(i.dueDate);
      return d >= start && d <= now;
    });
  }

  const totalPaid = installments.filter(i => i.status === 'paid').reduce((s, i) => s + i.amount, 0);
  const totalPending = installments.filter(i => i.status === 'pending').reduce((s, i) => s + i.amount, 0);
  const totalOverdue = installments.filter(i => i.status === 'overdue').reduce((s, i) => s + i.amount, 0);
  const nextInstallment = installments.find(i => i.status !== 'paid');

  const periodText = period === 'daily' ? 'do dia' : period === 'weekly' ? 'da semana' : period === 'monthly' ? 'do mês' : '';

  return `Olá ${clientName}, segue o resumo ${periodText} do seu empréstimo:

Total: R$ ${loan.totalAmount.toFixed(2)}
Parcela: R$ ${loan.installmentValue.toFixed(2)} (${loan.installmentsCount} vezes)

Pago: R$ ${totalPaid.toFixed(2)}
Pendente: R$ ${totalPending.toFixed(2)}
Atrasado: R$ ${totalOverdue.toFixed(2)}

Próximo pagamento: ${nextInstallment ? format(new Date(nextInstallment.dueDate), 'dd/MM') : 'N/A'}

Qualquer dúvida estou à disposição.`;
}
