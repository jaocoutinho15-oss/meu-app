import React, { useState, useEffect, useMemo, memo, useCallback } from "react";
import imageCompression from 'browser-image-compression';
import { 
  collection, 
  collectionGroup,
  query, 
  where, 
  orderBy, 
  onSnapshot, 
  addDoc, 
  updateDoc, 
  deleteDoc, 
  setDoc,
  doc,
  getDoc,
  writeBatch,
  getDocs,
  Timestamp,
  arrayUnion,
  increment
} from "firebase/firestore";
import { 
  signInWithPopup, 
  signInWithRedirect,
  getRedirectResult,
  GoogleAuthProvider, 
  onAuthStateChanged, 
  User,
  signOut,
  signInWithEmailAndPassword,
  createUserWithEmailAndPassword,
  sendPasswordResetEmail,
  updatePassword,
  reauthenticateWithCredential,
  EmailAuthProvider,
  updateProfile,
  updateEmail
} from "firebase/auth";
import { 
  ref, 
  uploadBytes, 
  getDownloadURL, 
  deleteObject 
} from "firebase/storage";
import { db, auth, storage } from "./firebase";
import { motion, AnimatePresence } from "motion/react";
import { 
  Plus, 
  TrendingUp, 
  Wallet, 
  HandCoins, 
  Pencil, 
  Trash2, 
  Check, 
  X, 
  LogIn, 
  LogOut, 
  Calendar, 
  MessageCircle, 
  FileText, 
  Bell,
  BellOff,
  ChevronRight,
  ChevronLeft,
  MapPin,
  ArrowLeft,
  Users,
  User as UserIcon,
  UserCircle,
  Camera,
  Image as ImageIcon,
  Shield,
  CheckCircle2,
  AlertCircle,
  Maximize2,
  Upload,
  Lock,
  Key,
  Eye,
  EyeOff,
  Search,
  PieChart,
  FolderOpen,
  Download,
  ImagePlus,
  FilePlus,
  BarChart3,
  Filter,
  Target,
  PlusCircle,
  Settings,
  Moon,
  Sun,
  Monitor,
  Fingerprint,
  Smartphone
} from "lucide-react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { 
  AlertDialog, 
  AlertDialogAction, 
  AlertDialogCancel, 
  AlertDialogContent, 
  AlertDialogDescription, 
  AlertDialogFooter, 
  AlertDialogHeader, 
  AlertDialogTitle, 
  AlertDialogTrigger 
} from "@/components/ui/alert-dialog";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { Checkbox } from "@/components/ui/checkbox";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { ScrollArea } from "@/components/ui/scroll-area";
import PageHeader from "./components/PageHeader";
import { formatCurrency } from "./lib/formatters";
import { toast, Toaster } from "sonner";
import { format, isBefore, startOfDay, endOfDay, startOfWeek, endOfWeek, startOfMonth, endOfMonth, startOfYear, endOfYear, subDays, isWithinInterval, addDays } from "date-fns";
import { ptBR } from "date-fns/locale";
import { 
  BarChart, 
  Bar, 
  XAxis, 
  YAxis, 
  CartesianGrid, 
  Tooltip, 
  ResponsiveContainer,
  LineChart,
  Line,
  AreaChart,
  Area,
  Cell
} from 'recharts';
import { generateInstallments, getWhatsAppMessage, getWhatsAppSummaryMessage, Frequency } from "./lib/loanUtils";
import { jsPDF } from "jspdf";
import autoTable from "jspdf-autotable";

// --- Types ---
interface Capital {
  id: string;
  name: string;
  color: string;
  balance: number;
  uid: string;
  created_date: string;
}

interface GeneralCapital {
  available_amount: number;
  lent_amount: number;
  profit: number;
  uid: string;
}

interface Loan {
  id: string;
  clientName: string;
  clientPhone: string;
  amount: number;
  interestRate: number;
  totalAmount: number;
  frequency: Frequency;
  installmentsCount: number;
  installmentValue: number;
  startDate: string;
  includeSundays: boolean;
  paymentDay: number;
  capitalId: string;
  status: 'active' | 'completed' | 'cancelled';
  amountPaid?: number;
  uid: string;
  created_date: string;
}

interface Installment {
  id: string;
  number: number;
  dueDate: string;
  amount: number;
  status: 'pending' | 'paid' | 'overdue';
  paidDate?: string;
  loanId: string;
  uid: string;
}

interface Client {
  id: string;
  name: string;
  phone: string;
  email?: string;
  cpf?: string;
  observations?: string;
  profilePhotoUrl?: string;
  photos?: string[];
  docRgUrl?: string;
  docCpfUrl?: string;
  docResidenceUrl?: string;
  faceRegistered?: boolean;
  address?: string;
  addressNumber?: string;
  neighborhood?: string;
  city?: string;
  mapsLink?: string;
  uid: string;
  created_date: string;
}

interface ClientFile {
  id: string;
  type: 'Contrato' | 'RG' | 'CPF' | 'Comprovante de residência' | 'Outros';
  url: string;
  uploadDate: string;
  observation?: string;
  category: 'Contratos' | 'Documentos' | 'Outros';
  uid: string;
}

interface UserProfile {
  uid: string;
  email: string;
  displayName?: string;
  photoURL?: string;
  pin?: string;
  capitalGoal?: number;
  theme?: 'light' | 'dark' | 'system';
  notificationsEnabled?: boolean;
  biometricsEnabled?: boolean;
}

interface Withdrawal {
  id: string;
  amount: number;
  date: string;
  capitalId: string;
  category: "Alimentação" | "Transporte" | "Pessoal" | "Emergência" | "Outros";
  description?: string;
  uid: string;
  created_date: string;
}

interface AppContribution {
  id: string;
  amount: number;
  date: string;
  description?: string;
  uid: string;
  created_date: string;
}

// --- Error Handling ---
enum OperationType {
  CREATE = 'create',
  UPDATE = 'update',
  DELETE = 'delete',
  LIST = 'list',
  GET = 'get',
  WRITE = 'write',
}

function handleFirestoreError(error: unknown, operationType: OperationType, path: string | null) {
  console.error('Firestore Error: ', error);
  toast.error("Erro no banco de dados. Verifique as permissões.");
}

async function uploadImage(file: File, path: string): Promise<string> {
  const storageRef = ref(storage, path);
  
  // Compress image if it's an image file
  let fileToUpload = file;
  if (file.type.startsWith('image/')) {
    try {
      const options = {
        maxSizeMB: 0.5,
        maxWidthOrHeight: 1280,
        useWebWorker: true
      };
      fileToUpload = await imageCompression(file, options);
    } catch (error) {
      console.error("Compression failed, uploading original:", error);
    }
  }

  await uploadBytes(storageRef, fileToUpload);
  return await getDownloadURL(storageRef);
}

function Skeleton({ className }: { className?: string }) {
  return <div className={`animate-pulse bg-muted rounded-xl ${className}`} />;
}

// --- Components ---

const COLORS = [
  { label: "Verde", value: "#10b981" },
  { label: "Azul", value: "#3b82f6" },
  { label: "Roxo", value: "#8b5cf6" },
  { label: "Rosa", value: "#ec4899" },
  { label: "Laranja", value: "#f97316" },
  { label: "Vermelho", value: "#ef4444" },
];

interface CapitalFormProps {
  key?: React.Key;
  initial?: any;
  onSave: (data: any) => void;
  onCancel: () => void;
}

function CapitalForm({ initial, onSave, onCancel }: CapitalFormProps) {
  const [form, setForm] = useState({
    name: initial?.name || "",
    color: initial?.color || COLORS[0].value,
    balance: initial?.balance || "",
  });

  async function handleSave() {
    if (!form.name || !form.balance) { toast.error("Preencha nome e valor."); return; }
    const amount = parseFloat(form.balance as string);
    const data = {
      name: form.name,
      color: form.color,
      balance: amount,
    };
    onSave(data);
  }

  return (
    <div className="bg-card border border-border rounded-2xl p-4 space-y-3">
      <p className="font-semibold text-sm">{initial ? "Editar Saldo" : "Novo Aporte"}</p>
      <div>
        <Label>Nome</Label>
        <Input placeholder="Ex: João Victor" className="rounded-xl h-11 mt-1" value={form.name} onChange={e => setForm(f => ({ ...f, name: e.target.value }))} />
      </div>
      <div>
        <Label>Valor do Aporte (R$)</Label>
        <Input type="number" step="100" placeholder="5000" className="rounded-xl h-11 mt-1" value={form.balance} onChange={e => setForm(f => ({ ...f, balance: e.target.value }))} />
      </div>
      <div>
        <Label>Cor</Label>
        <div className="flex gap-2 mt-1 flex-wrap">
          {COLORS.map(c => (
            <button key={c.value} onClick={() => setForm(f => ({ ...f, color: c.value }))}
              className="h-8 w-8 rounded-full border-2 transition-all"
              style={{ backgroundColor: c.value, borderColor: form.color === c.value ? "#000" : "transparent" }}
            />
          ))}
        </div>
      </div>
      <div className="flex gap-2 pt-1">
        <Button size="sm" className="flex-1 rounded-xl" onClick={handleSave}><Check className="h-4 w-4 mr-1" /> Salvar</Button>
        <Button size="sm" variant="outline" className="rounded-xl" onClick={onCancel}><X className="h-4 w-4" /></Button>
      </div>
    </div>
  );
}

function AppContributionForm({ onSave, onCancel }: { onSave: (data: any) => void, onCancel: () => void }) {
  const [form, setForm] = useState({
    amount: "",
    date: format(new Date(), 'yyyy-MM-dd'),
    description: "",
  });

  function handleSave() {
    if (!form.amount || !form.date) {
      toast.error("Preencha o valor e a data.");
      return;
    }
    onSave({
      amount: parseFloat(form.amount),
      date: new Date(form.date).toISOString(),
      description: form.description,
    });
  }

  return (
    <div className="bg-card border border-border rounded-2xl p-4 space-y-3">
      <div className="flex items-center justify-between">
        <p className="font-bold text-sm">Adicionar ao Capital do App</p>
        <Button variant="ghost" size="sm" onClick={onCancel}><X className="h-4 w-4" /></Button>
      </div>
      <div className="space-y-3">
        <div>
          <Label>Valor (R$)</Label>
          <Input type="number" placeholder="1000" className="rounded-xl h-11 mt-1" value={form.amount} onChange={e => setForm(f => ({ ...f, amount: e.target.value }))} />
        </div>
        <div>
          <Label>Data</Label>
          <Input type="date" className="rounded-xl h-11 mt-1" value={form.date} onChange={e => setForm(f => ({ ...f, date: e.target.value }))} />
        </div>
        <div>
          <Label>Descrição (Opcional)</Label>
          <Input placeholder="Ex: Aporte extra" className="rounded-xl h-11 mt-1" value={form.description} onChange={e => setForm(f => ({ ...f, description: e.target.value }))} />
        </div>
        <Button className="w-full rounded-xl" onClick={handleSave}>Confirmar Aporte</Button>
      </div>
    </div>
  );
}

interface CapitalCardProps {
  key?: React.Key;
  capital: any;
  onEdit: (c: any) => void;
  onDelete: (id: string) => void;
}

const CapitalCard = memo(({ capital, onEdit, onDelete }: CapitalCardProps) => {
  return (
    <motion.div 
      whileHover={{ scale: 1.01 }}
      whileTap={{ scale: 0.98 }}
      className="bg-card border border-border rounded-[1.5rem] p-4 shadow-sm hover:shadow-md transition-shadow"
    >
      <div className="flex items-center justify-between mb-3">
        <div className="flex items-center gap-2">
          <div className="h-4 w-4 rounded-full shadow-sm" style={{ backgroundColor: capital.color || "#10b981" }} />
          <span className="font-bold tracking-tight">{capital.name}</span>
        </div>
        <div className="flex gap-1">
          <button onClick={() => onEdit(capital)} className="h-8 w-8 rounded-lg bg-secondary flex items-center justify-center hover:bg-primary hover:text-primary-foreground transition-all duration-300">
            <Pencil className="h-3.5 w-3.5" />
          </button>
          <AlertDialog>
            <AlertDialogTrigger asChild>
            <button className="h-8 w-8 rounded-lg bg-red-50 flex items-center justify-center hover:bg-red-500 hover:text-white transition-all duration-300">
              <Trash2 className="h-3.5 w-3.5" />
            </button>
          </AlertDialogTrigger>
            <AlertDialogContent className="rounded-3xl">
              <AlertDialogHeader>
                <AlertDialogTitle className="font-bold">Remover saldo?</AlertDialogTitle>
                <AlertDialogDescription>Isso removerá o registro deste saldo individual.</AlertDialogDescription>
              </AlertDialogHeader>
              <AlertDialogFooter>
                <AlertDialogCancel variant="outline" className="rounded-xl">Cancelar</AlertDialogCancel>
                <AlertDialogAction variant="destructive" onClick={() => onDelete(capital.id)} className="rounded-xl">Remover</AlertDialogAction>
              </AlertDialogFooter>
            </AlertDialogContent>
          </AlertDialog>
        </div>
      </div>

      <div className="bg-secondary/20 p-3 rounded-2xl text-center border border-border/50">
        <p className="text-[10px] text-muted-foreground uppercase font-bold tracking-wide">Saldo Atual</p>
        <p className="text-xl font-bold text-primary data-precision">{formatCurrency(capital.balance)}</p>
      </div>
    </motion.div>
  );
});

// --- Loan Components ---

function LoanForm({ capitals, clients, onSave, onCancel, generalCapital }: { capitals: Capital[], clients: Client[], onSave: (data: any) => void, onCancel: () => void, generalCapital: GeneralCapital | null }) {
  const [form, setForm] = useState({
    clientName: "",
    clientPhone: "",
    clientId: "",
    amount: "",
    interestRate: "20",
    interestType: "simple" as 'simple' | 'compound',
    frequency: "daily" as Frequency,
    installmentsCount: "24",
    startDate: format(new Date(), 'yyyy-MM-dd'),
    includeSundays: false,
    paymentDay: "1",
    capitalId: capitals[0]?.id || "",
  });

  useEffect(() => {
    if (form.clientId) {
      const client = clients.find(c => c.id === form.clientId);
      if (client) {
        setForm(f => ({ ...f, clientName: client.name, clientPhone: client.phone }));
      }
    }
  }, [form.clientId, clients]);

  const totalAmount = useMemo(() => {
    const amt = parseFloat(form.amount) || 0;
    const rate = parseFloat(form.interestRate) || 0;
    if (form.interestType === 'compound') {
      const count = parseInt(form.installmentsCount) || 1;
      return amt * Math.pow(1 + (rate / 100), count);
    }
    return amt + (amt * (rate / 100));
  }, [form.amount, form.interestRate, form.interestType, form.installmentsCount]);

  const installmentValue = useMemo(() => {
    const count = parseInt(form.installmentsCount) || 1;
    return totalAmount / count;
  }, [totalAmount, form.installmentsCount]);

  function handleSave() {
    if (!form.clientName || !form.amount || !form.capitalId) {
      toast.error("Preencha os campos obrigatórios.");
      return;
    }
    onSave({
      ...form,
      amount: parseFloat(form.amount),
      interestRate: parseFloat(form.interestRate),
      totalAmount,
      installmentValue,
      installmentsCount: parseInt(form.installmentsCount),
      paymentDay: parseInt(form.paymentDay),
      status: 'active',
    });
  }

  return (
    <div className="bg-card border border-border rounded-2xl p-4 space-y-4">
      <div className="flex items-center justify-between">
        <p className="font-bold">Novo Empréstimo</p>
        <Button variant="ghost" size="sm" onClick={onCancel}><X className="h-4 w-4" /></Button>
      </div>

      <div className="space-y-3">
        <div className="space-y-1">
          <Label>Selecionar Cliente (Opcional)</Label>
          <Select value={form.clientId} onValueChange={v => setForm(f => ({ ...f, clientId: v }))}>
            <SelectTrigger>
              <SelectValue placeholder="Selecione um cliente" />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="none">Novo Cliente</SelectItem>
              {clients.map(c => (
                <SelectItem key={c.id} value={c.id}>{c.name}</SelectItem>
              ))}
            </SelectContent>
          </Select>
        </div>

        <div className="grid grid-cols-2 gap-3">
          <div className="space-y-1">
            <Label>Cliente</Label>
            <Input placeholder="Nome" value={form.clientName} onChange={e => setForm(f => ({ ...f, clientName: e.target.value }))} />
          </div>
          <div className="space-y-1">
            <Label>WhatsApp</Label>
            <Input placeholder="55..." value={form.clientPhone} onChange={e => setForm(f => ({ ...f, clientPhone: e.target.value }))} />
          </div>
        </div>

        <div className="grid grid-cols-2 gap-3">
          <div className="space-y-1">
            <Label>Valor (R$)</Label>
            <Input type="number" placeholder="1000" value={form.amount} onChange={e => setForm(f => ({ ...f, amount: e.target.value }))} />
          </div>
          <div className="space-y-1">
            <Label>Juros (%)</Label>
            <Input type="number" value={form.interestRate} onChange={e => setForm(f => ({ ...f, interestRate: e.target.value }))} />
          </div>
        </div>

        <div className="flex items-center gap-4">
          <div className="flex items-center gap-2">
            <Checkbox id="simple" checked={form.interestType === 'simple'} onCheckedChange={() => setForm(f => ({ ...f, interestType: 'simple' }))} />
            <Label htmlFor="simple" className="text-sm">Simples</Label>
          </div>
          <div className="flex items-center gap-2">
            <Checkbox id="compound" checked={form.interestType === 'compound'} onCheckedChange={() => setForm(f => ({ ...f, interestType: 'compound' }))} />
            <Label htmlFor="compound" className="text-sm">Compostos</Label>
          </div>
        </div>

        <div className="space-y-1">
          <Label>Responsável pelo Empréstimo</Label>
          <Select value={form.capitalId} onValueChange={v => setForm(f => ({ ...f, capitalId: v }))}>
            <SelectTrigger>
              <SelectValue placeholder="Selecione o responsável" />
            </SelectTrigger>
            <SelectContent>
              {capitals.map(c => (
                <SelectItem key={c.id} value={c.id}>{c.name}</SelectItem>
              ))}
            </SelectContent>
          </Select>
          <p className="text-[10px] text-muted-foreground mt-1">
            O valor será retirado do Capital Geral (Disponível: {formatCurrency(generalCapital?.available_amount || 0)})
          </p>
        </div>

        <div className="space-y-2">
          <Label>Frequência de Pagamento</Label>
          <div className="flex gap-2">
            {(['daily', 'weekly', 'monthly'] as Frequency[]).map(freq => (
              <Button 
                key={freq}
                size="sm"
                variant={form.frequency === freq ? "default" : "outline"}
                className="flex-1 rounded-xl capitalize"
                onClick={() => setForm(f => ({ ...f, frequency: freq }))}
              >
                {freq === 'daily' ? 'Diário' : freq === 'weekly' ? 'Semanal' : 'Mensal'}
              </Button>
            ))}
          </div>
        </div>

        <div className="grid grid-cols-2 gap-3">
          <div className="space-y-1">
            <Label>Parcelas</Label>
            <Input type="number" value={form.installmentsCount} onChange={e => setForm(f => ({ ...f, installmentsCount: e.target.value }))} />
          </div>
          <div className="space-y-1">
            <Label>Início</Label>
            <Input type="date" value={form.startDate} onChange={e => setForm(f => ({ ...f, startDate: e.target.value }))} />
          </div>
        </div>

        {form.frequency === 'daily' && (
          <div className="flex items-center gap-2">
            <Checkbox id="sundays" checked={form.includeSundays} onCheckedChange={v => setForm(f => ({ ...f, includeSundays: !!v }))} />
            <Label htmlFor="sundays" className="text-sm">Incluir domingos?</Label>
          </div>
        )}

        {form.frequency === 'monthly' && (
          <div className="space-y-1">
            <Label>Dia do Vencimento (1-31)</Label>
            <Input type="number" value={form.paymentDay} onChange={e => setForm(f => ({ ...f, paymentDay: e.target.value }))} />
          </div>
        )}

        <div className="bg-muted/50 p-3 rounded-xl space-y-1">
          <div className="flex justify-between text-sm">
            <span>Total com Juros:</span>
            <span className="font-bold">{formatCurrency(totalAmount)}</span>
          </div>
          <div className="flex justify-between text-sm">
            <span>Valor da Parcela:</span>
            <span className="font-bold text-primary">{formatCurrency(installmentValue)}</span>
          </div>
        </div>

        <Button className="w-full rounded-xl" onClick={handleSave}>Gerar Empréstimo</Button>
      </div>
    </div>
  );
}

function LoanDetails({ loan, installments, onUpdateInstallment, onCancelLoan, onBack }: { loan: Loan, installments: Installment[], onUpdateInstallment: (i: Installment, status: any) => void, onCancelLoan: (loan: Loan) => void, onBack: () => void }) {
  
  const summary = useMemo(() => {
    const paid = installments.filter(i => i.status === 'paid').reduce((s, i) => s + i.amount, 0);
    const pending = installments.filter(i => i.status === 'pending').reduce((s, i) => s + i.amount, 0);
    const overdue = installments.filter(i => i.status === 'overdue').reduce((s, i) => s + i.amount, 0);
    return { paid, pending, overdue };
  }, [installments]);

  function sendWhatsAppSummary() {
    const msg = getWhatsAppMessage(loan, installments);
    window.open(`https://wa.me/${loan.clientPhone}?text=${encodeURIComponent(msg)}`, '_blank');
  }

  function sendReminder() {
    const next = installments.find(i => i.status !== 'paid');
    if (!next) return;
    const msg = `Olá ${loan.clientName}, lembrete de sua parcela de ${formatCurrency(next.amount)} que vence amanhã (${format(new Date(next.dueDate), 'dd/MM/yyyy')}).`;
    window.open(`https://wa.me/${loan.clientPhone}?text=${encodeURIComponent(msg)}`, '_blank');
  }

  function generatePDF() {
    const doc = new jsPDF();
    doc.text(`Relatório de Empréstimo - ${loan.clientName}`, 14, 20);
    doc.text(`Valor Total: ${formatCurrency(loan.totalAmount)}`, 14, 30);
    doc.text(`Parcelas: ${loan.installmentsCount}x ${formatCurrency(loan.installmentValue)}`, 14, 40);
    
    const tableData = installments.map(i => [
      i.number,
      format(new Date(i.dueDate), 'dd/MM/yyyy'),
      formatCurrency(i.amount),
      i.status === 'paid' ? 'Pago' : i.status === 'overdue' ? 'Atrasado' : 'Pendente'
    ]);

    autoTable(doc, {
      head: [['#', 'Vencimento', 'Valor', 'Status']],
      body: tableData,
      startY: 50,
    });

    doc.save(`emprestimo_${loan.clientName}.pdf`);
  }

  return (
    <div className="space-y-4 pb-20">
      <div className="flex items-center gap-2 mb-2">
        <Button variant="ghost" size="sm" onClick={onBack}><ArrowLeft className="h-4 w-4" /></Button>
        <h2 className="font-bold text-lg">Detalhes do Empréstimo</h2>
      </div>

      <div className="bg-card border border-border rounded-2xl p-4 space-y-4">
        <div className="flex justify-between items-start">
          <div>
            <p className="font-bold text-xl">{loan.clientName}</p>
            <p className="text-sm text-muted-foreground">{loan.clientPhone}</p>
          </div>
          <div className="bg-primary/10 text-primary text-xs font-bold px-2 py-1 rounded-full uppercase">
            {loan.status}
          </div>
        </div>

        <div className="grid grid-cols-3 gap-2">
          <div className="bg-emerald-50 p-2 rounded-xl text-center">
            <p className="text-[10px] text-muted-foreground">Pago</p>
            <p className="text-sm font-bold text-emerald-600">{formatCurrency(summary.paid)}</p>
          </div>
          <div className="bg-amber-50 p-2 rounded-xl text-center">
            <p className="text-[10px] text-muted-foreground">Pendente</p>
            <p className="text-sm font-bold text-amber-600">{formatCurrency(summary.pending)}</p>
          </div>
          <div className="bg-red-50 p-2 rounded-xl text-center">
            <p className="text-[10px] text-muted-foreground">Atrasado</p>
            <p className="text-sm font-bold text-red-600">{formatCurrency(summary.overdue)}</p>
          </div>
        </div>

        <div className="flex flex-wrap gap-2">
          <Button size="sm" variant="outline" className="rounded-xl gap-1 flex-1" onClick={sendWhatsAppSummary}>
            <MessageCircle className="h-4 w-4 text-emerald-500" /> Resumo
          </Button>
          <Button size="sm" variant="outline" className="rounded-xl gap-1 flex-1" onClick={sendReminder}>
            <Bell className="h-4 w-4 text-amber-500" /> Lembrete
          </Button>
          <Button size="sm" variant="outline" className="rounded-xl gap-1 flex-1" onClick={generatePDF}>
            <FileText className="h-4 w-4 text-blue-500" /> PDF
          </Button>
        </div>

        {loan.status === 'active' && (
          <AlertDialog>
            <AlertDialogTrigger asChild>
            <Button size="sm" variant="destructive" className="w-full rounded-xl gap-2 mt-2">
              <Trash2 className="h-4 w-4" /> Cancelar Empréstimo
            </Button>
          </AlertDialogTrigger>
            <AlertDialogContent>
              <AlertDialogHeader>
                <AlertDialogTitle>Cancelar Empréstimo?</AlertDialogTitle>
                <AlertDialogDescription>
                  Tem certeza que deseja cancelar este empréstimo? Esta ação irá estornar o capital pendente para o saldo disponível e marcar o empréstimo como cancelado.
                </AlertDialogDescription>
              </AlertDialogHeader>
              <AlertDialogFooter>
                <AlertDialogCancel>Voltar</AlertDialogCancel>
                <AlertDialogAction 
                  className="bg-red-600 hover:bg-red-700"
                  onClick={() => onCancelLoan(loan)}
                >
                  Confirmar Cancelamento
                </AlertDialogAction>
              </AlertDialogFooter>
            </AlertDialogContent>
          </AlertDialog>
        )}
      </div>

      <div className="space-y-2">
        <p className="font-bold text-sm px-1">Parcelas</p>
        <div className="space-y-2">
          {installments.map(inst => (
            <div key={inst.id} className="bg-card border border-border rounded-xl p-3 flex items-center justify-between">
              <div className="flex items-center gap-3">
                <div className={`h-8 w-8 rounded-full flex items-center justify-center text-xs font-bold ${inst.status === 'paid' ? 'bg-emerald-100 text-emerald-700' : inst.status === 'overdue' ? 'bg-red-100 text-red-700' : 'bg-secondary text-muted-foreground'}`}>
                  {inst.number}
                </div>
                <div>
                  <p className="text-sm font-bold">{formatCurrency(inst.amount)}</p>
                  <p className={`text-[10px] ${inst.status === 'overdue' ? 'text-red-500 font-bold' : 'text-muted-foreground'}`}>
                    Vence: {format(new Date(inst.dueDate), 'dd/MM/yyyy')}
                  </p>
                </div>
              </div>
              <div className="flex gap-1">
                {inst.status !== 'paid' ? (
                  <Button size="sm" className="h-8 rounded-lg bg-emerald-500 hover:bg-emerald-600" onClick={() => onUpdateInstallment(inst, 'paid')}>
                    <Check className="h-4 w-4" />
                  </Button>
                ) : (
                  <Button size="sm" variant="ghost" className="h-8 rounded-lg text-muted-foreground" onClick={() => onUpdateInstallment(inst, 'pending')}>
                    Desfazer
                  </Button>
                )}
              </div>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
}

function PinKeypad({ onNumber, onDelete, onClear }: { onNumber: (n: string) => void, onDelete: () => void, onClear: () => void }) {
  const numbers = ["1", "2", "3", "4", "5", "6", "7", "8", "9", "C", "0", "del"];

  return (
    <div className="grid grid-cols-3 gap-3 w-full max-w-[280px] mx-auto">
      {numbers.map((n) => (
        <button
          key={n}
          onClick={() => {
            if (n === "del") onDelete();
            else if (n === "C") onClear();
            else onNumber(n);
          }}
          className={`h-16 w-16 rounded-full flex items-center justify-center text-xl font-bold transition-all active:scale-90 ${
            n === "del" || n === "C" 
            ? "bg-secondary text-muted-foreground hover:bg-secondary/80" 
            : "bg-card border border-border hover:border-primary/50 hover:bg-primary/5"
          }`}
        >
          {n === "del" ? <X className="h-6 w-6" /> : n === "C" ? "C" : n}
        </button>
      ))}
    </div>
  );
}

function LockScreen({ 
  profile, 
  onUnlock 
}: { 
  profile: UserProfile, 
  onUnlock: () => void 
}) {
  const [pin, setPin] = useState("");
  const [attempts, setAttempts] = useState(0);
  const [isBlocked, setIsBlocked] = useState(false);
  const [error, setError] = useState("");
  const pinLength = profile.pin?.length || 4;

  useEffect(() => {
    if (attempts >= 5) {
      setIsBlocked(true);
      setError("Muitas tentativas. Bloqueado por 30 segundos.");
      const timer = setTimeout(() => {
        setIsBlocked(false);
        setAttempts(0);
        setError("");
      }, 30000);
      return () => clearTimeout(timer);
    }
  }, [attempts]);

  const handleNumber = (n: string) => {
    if (isBlocked || pin.length >= pinLength) return;
    const newPin = pin + n;
    setPin(newPin);
    setError("");

    if (newPin.length === pinLength) {
      console.log("PIN Entry Complete:", { entry: newPin, expected: profile.pin });
      if (newPin === profile.pin) {
        console.log("PIN Correct, Unlocking...");
        onUnlock();
      } else {
        setAttempts(prev => prev + 1);
        setError("PIN incorreto");
        setTimeout(() => setPin(""), 500);
      }
    }
  };

  const handleBiometrics = () => {
    if (profile.biometricsEnabled) {
      toast.info("Simulando Biometria: Desbloqueado!");
      onUnlock();
    } else {
      toast.error("Biometria não ativada");
    }
  };

  return (
    <div className="fixed inset-0 z-[200] bg-background flex flex-col items-center justify-center p-8 animate-in fade-in duration-500">
      <div className="flex flex-col items-center space-y-8 w-full max-w-xs text-center">
        <div className="space-y-2">
          <div className="h-20 w-20 bg-primary/10 rounded-[2rem] flex items-center justify-center mx-auto mb-4">
            <Lock className="h-10 w-10 text-primary" />
          </div>
          <h2 className="text-2xl font-bold">Acesso Bloqueado</h2>
          <p className="text-sm text-muted-foreground">Digite seu PIN para continuar</p>
        </div>

        <div className="flex justify-center gap-4 h-4">
          {Array.from({ length: pinLength }).map((_, i) => (
            <div 
              key={i} 
              className={`h-4 w-4 rounded-full border-2 transition-all duration-200 ${
                i < pin.length ? "bg-primary border-primary scale-110" : "border-muted-foreground/30"
              }`} 
            />
          ))}
        </div>

        {error && <p className="text-red-500 text-xs font-bold animate-bounce">{error}</p>}

        <PinKeypad 
          onNumber={handleNumber} 
          onDelete={() => setPin(p => p.slice(0, -1))} 
          onClear={() => setPin("")} 
        />

        <div className="w-full flex justify-between items-center px-4 pt-4">
          {profile.biometricsEnabled ? (
            <Button variant="ghost" className="gap-2 text-primary" onClick={handleBiometrics}>
              <Fingerprint className="h-5 w-5" /> Biometria
            </Button>
          ) : <div />}
          <Button variant="ghost" className="text-muted-foreground" onClick={() => signOut(auth)}>Sair</Button>
        </div>
      </div>
    </div>
  );
}

function CreatePinScreen({ onSetPin }: { onSetPin: (pin: string) => void }) {
  const [step, setStep] = useState<'length' | 'create' | 'confirm'>('length');
  const [pinLength, setPinLength] = useState<4 | 6>(4);
  const [pin, setPin] = useState("");
  const [confirmPin, setConfirmPin] = useState("");
  const [error, setError] = useState("");

  const handleCreateNumber = (n: string) => {
    if (step === 'create') {
      const newPin = pin + n;
      if (newPin.length <= pinLength) setPin(newPin);
      if (newPin.length === pinLength) {
        setTimeout(() => setStep('confirm'), 300);
      }
    } else if (step === 'confirm') {
      const newPin = confirmPin + n;
      if (newPin.length <= pinLength) setConfirmPin(newPin);
      if (newPin.length === pinLength) {
        if (newPin === pin) {
          onSetPin(pin);
        } else {
          setError("PINs não coincidem");
          setTimeout(() => {
            setConfirmPin("");
            setError("");
          }, 1000);
        }
      }
    }
  };

  return (
    <div className="fixed inset-0 z-[200] bg-background flex flex-col items-center justify-center p-8">
      <div className="w-full max-w-xs text-center space-y-8">
        <div className="space-y-2">
          <div className="h-16 w-16 bg-emerald-100 text-emerald-600 rounded-3xl flex items-center justify-center mx-auto mb-4">
            <Shield className="h-8 w-8" />
          </div>
          <h2 className="text-2xl font-bold">
            {step === 'length' ? 'Configurar PIN' : step === 'create' ? 'Crie seu PIN' : 'Confirme seu PIN'}
          </h2>
          <p className="text-sm text-muted-foreground">
            {step === 'length' ? 'Escolha o tamanho do seu código de segurança' : 'Digite seu novo código numérico'}
          </p>
        </div>

        {step === 'length' ? (
          <div className="grid grid-cols-2 gap-4">
            <Button variant="outline" className="h-24 rounded-3xl flex-col gap-2 border-2 hover:border-primary transition-all" onClick={() => { setPinLength(4); setStep('create'); }}>
              <span className="text-2xl font-bold">4</span>
              <span className="text-xs opacity-60">Dígitos</span>
            </Button>
            <Button variant="outline" className="h-24 rounded-3xl flex-col gap-2 border-2 hover:border-primary transition-all" onClick={() => { setPinLength(6); setStep('create'); }}>
              <span className="text-2xl font-bold">6</span>
              <span className="text-xs opacity-60">Dígitos</span>
            </Button>
          </div>
        ) : (
          <>
            <div className="flex justify-center gap-4 h-4">
              {Array.from({ length: pinLength }).map((_, i) => (
                <div 
                  key={i} 
                  className={`h-4 w-4 rounded-full border-2 transition-all duration-200 ${
                    (step === 'create' ? i < pin.length : i < confirmPin.length) ? "bg-primary border-primary scale-110" : "border-muted-foreground/30"
                  }`} 
                />
              ))}
            </div>
            {error && <p className="text-red-500 text-xs font-bold">{error}</p>}
            <PinKeypad 
              onNumber={handleCreateNumber} 
              onDelete={() => step === 'create' ? setPin(p => p.slice(0, -1)) : setConfirmPin(p => p.slice(0, -1))} 
              onClear={() => step === 'create' ? setPin("") : setConfirmPin("")} 
            />
            {step === 'confirm' && (
              <Button variant="ghost" onClick={() => { setStep('create'); setPin(""); setConfirmPin(""); }} className="text-muted-foreground">Reiniciar</Button>
            )}
          </>
        )}
      </div>
    </div>
  );
}

function PinModal({ isOpen, onVerify, onCancel, title = "Digite seu PIN", length = 4 }: { isOpen: boolean, onVerify: (pin: string) => void, onCancel: () => void, title?: string, length?: number }) {
  const [pin, setPin] = useState("");

  if (!isOpen) return null;

  const handleNumber = (n: string) => {
    if (pin.length < length) {
      const newPin = pin + n;
      setPin(newPin);
      if (newPin.length === length) {
        setTimeout(() => {
          onVerify(newPin);
          setPin("");
        }, 200);
      }
    }
  };

  return (
    <div className="fixed inset-0 z-[300] bg-background/80 backdrop-blur-sm flex items-center justify-center p-6">
      <div className="bg-card border border-border rounded-[2.5rem] p-8 w-full max-w-xs shadow-2xl animate-in zoom-in-95 duration-200">
        <div className="flex flex-col items-center text-center space-y-6">
          <div className="h-14 w-14 bg-primary/10 rounded-2xl flex items-center justify-center">
            <Lock className="h-7 w-7 text-primary" />
          </div>
          <div>
            <h3 className="font-bold text-xl">{title}</h3>
            <p className="text-xs text-muted-foreground">Confirme sua identidade</p>
          </div>
          
          <div className="flex justify-center gap-4 h-4 mb-4">
            {Array.from({ length }).map((_, i) => (
              <div 
                key={i} 
                className={`h-4 w-4 rounded-full border-2 transition-all duration-200 ${
                  i < pin.length ? "bg-primary border-primary scale-110" : "border-muted-foreground/30"
                }`} 
              />
            ))}
          </div>

          <PinKeypad 
            onNumber={handleNumber} 
            onDelete={() => setPin(p => p.slice(0, -1))} 
            onClear={() => setPin("")} 
          />

          <Button variant="ghost" className="w-full rounded-xl text-muted-foreground" onClick={onCancel}>Cancelar</Button>
        </div>
      </div>
    </div>
  );
}

function AuthScreen({ onLogin }: { onLogin: () => void }) {
  const [isRegister, setIsRegister] = useState(false);
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [loading, setLoading] = useState(false);
  const [showPass, setShowPass] = useState(false);

  async function handleEmailAuth() {
    if (!email || !password) { toast.error("Preencha todos os campos"); return; }
    setLoading(true);
    try {
      if (isRegister) {
        await createUserWithEmailAndPassword(auth, email, password);
        toast.success("Conta criada com sucesso!");
      } else {
        await signInWithEmailAndPassword(auth, email, password);
      }
    } catch (err: any) {
      toast.error(err.message);
    } finally {
      setLoading(false);
    }
  }

  async function handleGoogleLogin() {
    const provider = new GoogleAuthProvider();
    setLoading(true);
    try {
      // In sandboxed environments like AI Studio, signInWithPopup is more reliable than redirect
      await signInWithPopup(auth, provider);
    } catch (err: any) {
      console.error("Login Error:", err);
      // If popup is blocked, we can try redirect as fallback, but popup is preferred here
      if (err.code === 'auth/popup-blocked') {
        toast.error("O popup de login foi bloqueado. Por favor, permita popups para este site.");
      } else {
        toast.error("Erro no login: " + err.message);
      }
      setLoading(false);
    }
  }

  async function handleResetPassword() {
    if (!email) { toast.error("Digite seu email primeiro"); return; }
    try {
      await sendPasswordResetEmail(auth, email);
      toast.success("Email de recuperação enviado!");
    } catch (err: any) {
      toast.error(err.message);
    }
  }

  return (
    <div className="min-h-screen flex flex-col items-center justify-center bg-background p-6 text-center">
      <div className="w-20 h-20 bg-primary/10 rounded-3xl flex items-center justify-center mb-6">
        <Wallet className="h-10 w-10 text-primary" />
      </div>
      <h1 className="text-3xl font-bold mb-2">Capital Flow</h1>
      <p className="text-muted-foreground mb-8 max-w-xs">Gerencie seus capitais, empréstimos e lucros de forma profissional.</p>
      
      <div className="w-full max-w-sm space-y-4">
        <div className="space-y-2 text-left">
          <Label>Email</Label>
          <Input type="email" placeholder="seu@email.com" className="h-12 rounded-2xl" value={email} onChange={e => setEmail(e.target.value)} />
        </div>
        <div className="space-y-2 text-left relative">
          <Label>Senha</Label>
          <Input type={showPass ? "text" : "password"} placeholder="******" className="h-12 rounded-2xl pr-10" value={password} onChange={e => setPassword(e.target.value)} />
          <button className="absolute right-3 top-9 text-muted-foreground" onClick={() => setShowPass(!showPass)}>
            {showPass ? <EyeOff className="h-4 w-4" /> : <Eye className="h-4 w-4" />}
          </button>
        </div>

        <Button className="w-full h-12 rounded-2xl text-lg gap-2" onClick={handleEmailAuth} disabled={loading}>
          {loading ? <div className="h-5 w-5 border-2 border-white/20 border-t-white rounded-full animate-spin" /> : (isRegister ? "Cadastrar" : "Entrar")}
        </Button>

        <div className="flex items-center justify-between px-1">
          <button className="text-xs text-primary font-bold hover:underline" onClick={() => setIsRegister(!isRegister)}>
            {isRegister ? "Já tem conta? Entre" : "Criar nova conta"}
          </button>
          {!isRegister && (
            <button className="text-xs text-muted-foreground hover:underline" onClick={handleResetPassword}>
              Esqueceu a senha?
            </button>
          )}
        </div>

        <div className="relative py-4">
          <div className="absolute inset-0 flex items-center"><div className="w-full border-t border-border"></div></div>
          <div className="relative flex justify-center text-xs uppercase"><span className="bg-background px-2 text-muted-foreground">Ou continue com</span></div>
        </div>

        <Button variant="outline" onClick={handleGoogleLogin} className="w-full h-12 rounded-2xl gap-2 text-lg">
          {loading ? <div className="h-5 w-5 border-2 border-primary/20 border-t-primary rounded-full animate-spin" /> : <><LogIn className="h-5 w-5" /> Google</>}
        </Button>

        <p className="text-[10px] text-muted-foreground mt-2">
          Dica: Se o login do Google não abrir, verifique se seu navegador está bloqueando popups.
        </p>

        <div className="pt-8 opacity-20 text-[8px] font-mono break-all">
          UA: {navigator.userAgent}
        </div>
      </div>
    </div>
  );
}

const Dashboard = memo(({ loans, clients, installments, withdrawals, capitals, generalCapital, userProfile, onUpdateProfile, appContributions }: { loans: Loan[], clients: Client[], installments: Installment[], withdrawals: Withdrawal[], capitals: Capital[], generalCapital: GeneralCapital | null, userProfile: UserProfile | null, onUpdateProfile: (data: Partial<UserProfile>) => void, appContributions: AppContribution[] }) => {
  const [isEditingGoal, setIsEditingGoal] = useState(false);
  const [newGoal, setNewGoal] = useState(userProfile?.capitalGoal?.toString() || "");

  const stats = useMemo(() => {
    const totalLent = generalCapital?.lent_amount || 0;
    const totalAvailable = generalCapital?.available_amount || 0;
    const totalProfit = generalCapital?.profit || 0;
    
    const totalToReceive = installments.filter(i => i.status !== 'paid').reduce((s, i) => s + i.amount, 0);
    const totalReceived = installments.filter(i => i.status === 'paid').reduce((s, i) => s + i.amount, 0);
    const overdueCount = installments.filter(i => i.status === 'overdue').length;
    
    const now = new Date();
    const startOfMonth = new Date(now.getFullYear(), now.getMonth(), 1).toISOString();
    const monthlyWithdrawals = withdrawals
      .filter(w => w.date >= startOfMonth)
      .reduce((s, w) => s + w.amount, 0);

    const withdrawalTotals = withdrawals.reduce((acc, w) => {
      if (w.capitalId === 'app') acc.app += w.amount;
      else {
        const cap = capitals.find(c => c.id === w.capitalId);
        if (cap?.name.toLowerCase().includes('joão')) acc.joao += w.amount;
        else if (cap?.name.toLowerCase().includes('vanessa')) acc.vanessa += w.amount;
        else acc.app += w.amount;
      }
      return acc;
    }, { joao: 0, vanessa: 0, app: 0 });

    const totalAppContributions = appContributions.reduce((s, c) => s + c.amount, 0);

    const totalInitial = capitals.reduce((s, c) => s + c.balance, 0);
    const lowCapital = totalAvailable < (totalInitial * 0.15); // 15% threshold

    const currentCapital = totalAvailable + totalLent;
    const goal = userProfile?.capitalGoal || 0;
    const progress = goal > 0 ? Math.min(100, (currentCapital / goal) * 100) : 0;
    const remaining = Math.max(0, goal - currentCapital);
    
    return { totalLent, totalToReceive, totalReceived, overdueCount, monthlyWithdrawals, totalAvailable, lowCapital, totalProfit, withdrawalTotals, currentCapital, goal, progress, remaining, totalAppContributions };
  }, [loans, installments, withdrawals, capitals, generalCapital, userProfile, appContributions]);

  // Alert logic
  useEffect(() => {
    if (stats.goal > 0) {
      const lastProgress = localStorage.getItem('last_progress');
      const currentProgress = stats.progress;
      
      if (currentProgress >= 100 && (!lastProgress || parseFloat(lastProgress) < 100)) {
        toast.success("🎉 Parabéns! Você atingiu 100% da sua meta de capital!");
      } else if (currentProgress >= 75 && (!lastProgress || parseFloat(lastProgress) < 75)) {
        toast.info("🚀 Quase lá! Você atingiu 75% da sua meta!");
      } else if (currentProgress >= 50 && (!lastProgress || parseFloat(lastProgress) < 50)) {
        toast.info("📈 Bom trabalho! Você atingiu 50% da sua meta!");
      }
      
      localStorage.setItem('last_progress', currentProgress.toString());
    }
  }, [stats.progress, stats.goal]);

  const handleSaveGoal = () => {
    const val = parseFloat(newGoal);
    if (isNaN(val)) {
      toast.error("Insira um valor válido");
      return;
    }
    onUpdateProfile({ capitalGoal: val });
    setIsEditingGoal(false);
    toast.success("Meta atualizada!");
  };

  return (
    <div className="space-y-6">
      {/* Meta de Capital Section */}
      <div className="bg-card border border-border rounded-3xl p-5 space-y-4 shadow-sm">
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-2">
            <div className="h-8 w-8 bg-emerald-100 rounded-xl flex items-center justify-center">
              <Target className="h-5 w-5 text-emerald-600" />
            </div>
            <p className="font-bold">Meta de Capital</p>
          </div>
          <Button variant="ghost" size="sm" className="h-8 rounded-lg text-xs" onClick={() => setIsEditingGoal(true)}>
            <Pencil className="h-3 w-3 mr-1" /> Editar
          </Button>
        </div>

        {isEditingGoal ? (
          <div className="flex gap-2 animate-in fade-in slide-in-from-top-1">
            <Input 
              type="number" 
              placeholder="Ex: 10000" 
              className="rounded-xl h-10" 
              value={newGoal} 
              onChange={e => setNewGoal(e.target.value)} 
            />
            <Button size="sm" className="rounded-xl h-10 px-4" onClick={handleSaveGoal}>Salvar</Button>
            <Button size="sm" variant="outline" className="rounded-xl h-10" onClick={() => setIsEditingGoal(false)}>X</Button>
          </div>
        ) : stats.goal > 0 ? (
          <div className="space-y-3">
            <div className="flex justify-between items-end">
              <div>
                <p className="text-[10px] text-muted-foreground uppercase font-bold">Progresso</p>
                <p className="text-2xl font-bold text-emerald-600">{stats.progress.toFixed(1)}%</p>
              </div>
              <div className="text-right">
                <p className="text-[10px] text-muted-foreground uppercase font-bold">Meta</p>
                <p className="text-sm font-bold">{formatCurrency(stats.goal)}</p>
              </div>
            </div>

            <div className="h-3 w-full bg-secondary rounded-full overflow-hidden">
              <div 
                className="h-full bg-emerald-500 transition-all duration-1000 ease-out" 
                style={{ width: `${stats.progress}%` }}
              />
            </div>

            <div className="flex justify-between items-center">
              <p className="text-[10px] text-muted-foreground">
                Atual: <span className="font-bold text-foreground">{formatCurrency(stats.currentCapital)}</span>
              </p>
              {stats.remaining > 0 ? (
                <p className="text-[10px] text-emerald-700 font-medium">
                  Faltam {formatCurrency(stats.remaining)} para a meta
                </p>
              ) : (
                <p className="text-[10px] text-emerald-600 font-bold flex items-center gap-1">
                  <CheckCircle2 className="h-3 w-3" /> Meta atingida!
                </p>
              )}
            </div>
          </div>
        ) : (
          <div className="py-4 text-center space-y-2">
            <p className="text-sm text-muted-foreground">Você ainda não definiu uma meta de capital.</p>
            <Button variant="outline" size="sm" className="rounded-xl" onClick={() => setIsEditingGoal(true)}>
              Definir Meta Agora
            </Button>
          </div>
        )}
      </div>

      <div className="grid grid-cols-2 gap-3">
        <div className="bg-primary text-primary-foreground p-4 rounded-3xl space-y-1">
          <p className="text-[10px] opacity-80 uppercase font-bold">Capital Total</p>
          <p className="text-lg font-bold">{formatCurrency(stats.totalAvailable + stats.totalLent)}</p>
        </div>
        <div className="bg-card border border-border p-4 rounded-3xl space-y-1">
          <p className="text-[10px] text-muted-foreground uppercase font-bold">Capital Disponível</p>
          <p className="text-lg font-bold text-primary">{formatCurrency(stats.totalAvailable)}</p>
        </div>
      </div>

      <div className="grid grid-cols-3 gap-3">
        <div className="bg-emerald-50 p-3 rounded-2xl text-center">
          <p className="text-[10px] text-muted-foreground">Lucro Total</p>
          <p className="text-sm font-bold text-emerald-600">{formatCurrency(stats.totalProfit)}</p>
        </div>
        <div className="bg-secondary p-3 rounded-2xl text-center">
          <p className="text-[10px] text-muted-foreground">Emprestado</p>
          <p className="text-sm font-bold">{formatCurrency(stats.totalLent)}</p>
        </div>
        <div className="bg-red-50 p-3 rounded-2xl text-center">
          <p className="text-[10px] text-muted-foreground">Retirado (Mês)</p>
          <p className="text-sm font-bold text-red-600">{formatCurrency(stats.monthlyWithdrawals)}</p>
        </div>
      </div>

      <div className="space-y-3">
        <p className="text-xs font-bold text-muted-foreground uppercase px-1">Retiradas Totais</p>
        <div className="grid grid-cols-3 gap-2">
          <div className="bg-card border border-border p-2 rounded-2xl text-center">
            <p className="text-[9px] text-muted-foreground">João Victor</p>
            <p className="text-xs font-bold text-blue-600">{formatCurrency(stats.withdrawalTotals.joao)}</p>
          </div>
          <div className="bg-card border border-border p-2 rounded-2xl text-center">
            <p className="text-[9px] text-muted-foreground">Vanessa</p>
            <p className="text-xs font-bold text-pink-600">{formatCurrency(stats.withdrawalTotals.vanessa)}</p>
          </div>
          <div className="bg-card border border-border p-2 rounded-2xl text-center">
            <p className="text-[9px] text-muted-foreground">Capital App</p>
            <p className="text-xs font-bold text-muted-foreground">{formatCurrency(stats.withdrawalTotals.app)}</p>
          </div>
        </div>
      </div>

      <div className="space-y-3">
        <p className="text-xs font-bold text-muted-foreground uppercase px-1">Saldos Individuais</p>
        <div className="grid grid-cols-2 gap-3">
          {capitals.map(c => (
            <div key={c.id} className="bg-card border border-border p-3 rounded-2xl flex items-center gap-2">
              <div className="h-2 w-2 rounded-full" style={{ backgroundColor: c.color }} />
              <div>
                <p className="text-[10px] text-muted-foreground leading-none mb-1">{c.name}</p>
                <p className="text-sm font-bold">{formatCurrency(c.balance)}</p>
              </div>
            </div>
          ))}
        </div>
      </div>

      {stats.lowCapital && (
        <div className="bg-amber-500 text-white p-4 rounded-2xl flex items-center gap-3 animate-pulse">
          <Bell className="h-6 w-6" />
          <div>
            <p className="text-sm font-bold">Capital Baixo!</p>
            <p className="text-xs opacity-90">Seu capital disponível está abaixo de 15% do inicial.</p>
          </div>
        </div>
      )}

      {stats.overdueCount > 0 && (
        <div className="bg-red-500 text-white p-4 rounded-2xl flex items-center gap-3">
          <AlertCircle className="h-6 w-6" />
          <div>
            <p className="text-sm font-bold">Atenção!</p>
            <p className="text-xs opacity-90">Você tem {stats.overdueCount} parcelas em atraso.</p>
          </div>
        </div>
      )}

      <div className="bg-card border border-border rounded-3xl p-5 space-y-4">
        <div className="flex items-center justify-between">
          <p className="font-bold">Gastos Mensais</p>
          <PieChart className="h-5 w-5 text-muted-foreground" />
        </div>
        <div className="h-32 flex items-end justify-between gap-2 px-2">
          {[40, 70, 45, 90, 65, 85, 100].map((h, i) => (
            <div key={i} className="flex-1 bg-red-100 rounded-t-lg relative group">
              <div className="absolute bottom-0 w-full bg-red-500 rounded-t-lg transition-all duration-500" style={{ height: `${h}%` }}></div>
            </div>
          ))}
        </div>
        <div className="flex justify-between text-[10px] text-muted-foreground px-1">
          <span>Seg</span><span>Ter</span><span>Qua</span><span>Qui</span><span>Sex</span><span>Sab</span><span>Dom</span>
        </div>
      </div>
    </div>
  );
});

const Reports = memo(({ loans, clients, installments, withdrawals, capitals, generalCapital, appContributions }: { loans: Loan[], clients: Client[], installments: Installment[], withdrawals: Withdrawal[], capitals: Capital[], generalCapital: GeneralCapital | null, appContributions: AppContribution[] }) => {
  const [period, setPeriod] = useState<'daily' | 'weekly' | 'monthly' | 'yearly' | 'custom'>('monthly');
  const [customRange, setCustomRange] = useState({ 
    start: format(startOfMonth(new Date()), 'yyyy-MM-dd'), 
    end: format(endOfMonth(new Date()), 'yyyy-MM-dd') 
  });
  const [selectedClientId, setSelectedClientId] = useState<string>('all');
  const [selectedStatus, setSelectedStatus] = useState<'all' | 'paid' | 'pending' | 'overdue'>('all');

  const dateRange = useMemo(() => {
    const now = new Date();
    switch (period) {
      case 'daily':
        return { start: startOfDay(now), end: endOfDay(now) };
      case 'weekly':
        return { start: startOfWeek(now, { weekStartsOn: 0 }), end: endOfWeek(now, { weekStartsOn: 0 }) };
      case 'monthly':
        return { start: startOfMonth(now), end: endOfMonth(now) };
      case 'yearly':
        return { start: startOfYear(now), end: endOfYear(now) };
      case 'custom':
        return { start: startOfDay(new Date(customRange.start)), end: endOfDay(new Date(customRange.end)) };
      default:
        return { start: startOfMonth(now), end: endOfMonth(now) };
    }
  }, [period, customRange]);

  const filteredData = useMemo(() => {
    const activeLoans = loans.filter(l => l.status !== 'cancelled');
    const activeLoanIds = activeLoans.map(l => l.id);

    let filteredInstallments = installments.filter(i => {
      const date = new Date(i.dueDate);
      return isWithinInterval(date, { start: dateRange.start, end: dateRange.end }) && activeLoanIds.includes(i.loanId);
    });

    const clientLoanIds = selectedClientId === 'all' ? null : activeLoans.filter(l => l.clientName === selectedClientId).map(l => l.id);

    filteredInstallments = filteredInstallments.filter(i => {
      const matchesClient = !clientLoanIds || clientLoanIds.includes(i.loanId);
      const matchesStatus = selectedStatus === 'all' || i.status === selectedStatus;
      return matchesClient && matchesStatus;
    });

    const filteredWithdrawals = withdrawals.filter(w => {
      const date = new Date(w.date);
      return isWithinInterval(date, { start: dateRange.start, end: dateRange.end });
    });

    const filteredLoans = activeLoans.filter(l => {
      const date = new Date(l.startDate);
      const inRange = isWithinInterval(date, { start: dateRange.start, end: dateRange.end });
      const matchesClient = selectedClientId === 'all' || l.clientName === selectedClientId;
      return inRange && matchesClient;
    });

    const filteredContributions = appContributions.filter(c => {
      const date = new Date(c.date);
      return isWithinInterval(date, { start: dateRange.start, end: dateRange.end });
    });

    return { installments: filteredInstallments, withdrawals: filteredWithdrawals, loans: filteredLoans, contributions: filteredContributions };
  }, [installments, withdrawals, loans, appContributions, dateRange, selectedClientId, selectedStatus]);

  const metrics = useMemo(() => {
    const totalLent = filteredData.loans.reduce((s, l) => s + l.amount, 0);
    const totalReceived = filteredData.installments.filter(i => i.status === 'paid').reduce((s, i) => s + i.amount, 0);
    const totalOpen = filteredData.installments.filter(i => i.status === 'pending').reduce((s, i) => s + i.amount, 0);
    const totalOverdue = filteredData.installments.filter(i => i.status === 'overdue').reduce((s, i) => s + i.amount, 0);
    
    const totalContributions = filteredData.contributions.reduce((s, c) => s + c.amount, 0);
    const entries = totalReceived + totalContributions;
    const withdrawalsSum = filteredData.withdrawals.reduce((s, w) => s + w.amount, 0);
    const exits = totalLent + withdrawalsSum;
    const expenses = withdrawalsSum;
    const growth = entries - exits;

    const activeClients = new Set(loans.filter(l => l.status === 'active').map(l => l.clientName)).size;
    const delinquentClients = new Set(installments.filter(i => i.status === 'overdue').map(i => {
      const loan = loans.find(l => l.id === i.loanId);
      return loan?.clientName;
    }).filter(Boolean)).size;
    const activeLoansCount = loans.filter(l => l.status === 'active').length;

    return { totalLent, totalReceived, totalOpen, totalOverdue, entries, exits, expenses, growth, activeClients, delinquentClients, activeLoansCount, totalContributions };
  }, [filteredData, loans, installments]);

  const chartData = useMemo(() => {
    const days: Record<string, { date: string, entries: number, exits: number }> = {};
    
    let curr = new Date(dateRange.start);
    while (curr <= dateRange.end) {
      const d = format(curr, 'dd/MM');
      days[d] = { date: d, entries: 0, exits: 0 };
      curr = addDays(curr, 1);
      if (Object.keys(days).length > 31) break;
    }

    filteredData.installments.filter(i => i.status === 'paid' && i.paidDate).forEach(i => {
      const d = format(new Date(i.paidDate!), 'dd/MM');
      if (days[d]) days[d].entries += i.amount;
    });

    filteredData.contributions.forEach(c => {
      const d = format(new Date(c.date), 'dd/MM');
      if (days[d]) days[d].entries += c.amount;
    });

    filteredData.loans.forEach(l => {
      const d = format(new Date(l.startDate), 'dd/MM');
      if (days[d]) days[d].exits += l.amount;
    });

    filteredData.withdrawals.forEach(w => {
      const d = format(new Date(w.date), 'dd/MM');
      if (days[d]) days[d].exits += w.amount;
    });

    return Object.values(days);
  }, [filteredData, dateRange]);

  return (
    <div className="space-y-6 pb-20">
      <div className="bg-card border border-border rounded-3xl p-4 space-y-4">
        <div className="flex items-center gap-2 text-primary mb-2">
          <Filter className="h-5 w-5" />
          <p className="font-bold">Filtros de Relatório</p>
        </div>

        <div className="space-y-3">
          <div className="flex flex-wrap gap-2">
            {(['daily', 'weekly', 'monthly', 'yearly', 'custom'] as const).map(p => (
              <Button 
                key={p} 
                size="sm" 
                variant={period === p ? "default" : "outline"}
                className="rounded-xl capitalize text-[10px] h-8"
                onClick={() => setPeriod(p)}
              >
                {p === 'daily' ? 'Diário' : p === 'weekly' ? 'Semanal' : p === 'monthly' ? 'Mensal' : p === 'yearly' ? 'Anual' : 'Personalizado'}
              </Button>
            ))}
          </div>

          {period === 'custom' && (
            <div className="grid grid-cols-2 gap-2">
              <Input type="date" value={customRange.start} onChange={e => setCustomRange(r => ({ ...r, start: e.target.value }))} className="rounded-xl h-9 text-xs" />
              <Input type="date" value={customRange.end} onChange={e => setCustomRange(r => ({ ...r, end: e.target.value }))} className="rounded-xl h-9 text-xs" />
            </div>
          )}

          <div className="grid grid-cols-2 gap-2">
            <Select value={selectedClientId} onValueChange={setSelectedClientId}>
              <SelectTrigger className="rounded-xl h-9 text-xs">
                <SelectValue placeholder="Cliente" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="all">Todos Clientes</SelectItem>
                {clients.map(c => <SelectItem key={c.id} value={c.name}>{c.name}</SelectItem>)}
              </SelectContent>
            </Select>

            <Select value={selectedStatus} onValueChange={(v: any) => setSelectedStatus(v)}>
              <SelectTrigger className="rounded-xl h-9 text-xs">
                <SelectValue placeholder="Status" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="all">Todos Status</SelectItem>
                <SelectItem value="paid">Pago</SelectItem>
                <SelectItem value="pending">Pendente</SelectItem>
                <SelectItem value="overdue">Atrasado</SelectItem>
              </SelectContent>
            </Select>
          </div>
        </div>
      </div>

      <div className="grid grid-cols-2 gap-3">
        <div className="bg-primary text-primary-foreground p-4 rounded-3xl space-y-1">
          <p className="text-[10px] opacity-80 uppercase font-bold">Total Emprestado</p>
          <p className="text-lg font-bold">{formatCurrency(metrics.totalLent)}</p>
        </div>
        <div className="bg-emerald-600 text-white p-4 rounded-3xl space-y-1">
          <p className="text-[10px] opacity-80 uppercase font-bold">Total Recebido</p>
          <p className="text-lg font-bold">{formatCurrency(metrics.totalReceived)}</p>
        </div>
      </div>

      <div className="grid grid-cols-2 gap-3">
        <div className="bg-emerald-50 p-4 rounded-3xl space-y-1 text-center border border-emerald-100">
          <p className="text-[10px] text-emerald-600 uppercase font-bold">Aportes Diretos</p>
          <p className="text-lg font-bold text-emerald-700">{formatCurrency(metrics.totalContributions)}</p>
        </div>
        <div className="bg-card border border-border p-4 rounded-3xl space-y-1 text-center">
          <p className="text-[10px] text-muted-foreground uppercase font-bold">Total Entradas</p>
          <p className="text-lg font-bold text-primary">{formatCurrency(metrics.entries)}</p>
        </div>
      </div>

      <div className="grid grid-cols-3 gap-2">
        <div className="bg-card border border-border p-3 rounded-2xl text-center">
          <p className="text-[9px] text-muted-foreground uppercase font-bold">Em Aberto</p>
          <p className="text-xs font-bold text-amber-600">{formatCurrency(metrics.totalOpen)}</p>
        </div>
        <div className="bg-card border border-border p-3 rounded-2xl text-center">
          <p className="text-[9px] text-muted-foreground uppercase font-bold">Atrasado</p>
          <p className="text-xs font-bold text-red-600">{formatCurrency(metrics.totalOverdue)}</p>
        </div>
        <div className="bg-card border border-border p-3 rounded-2xl text-center">
          <p className="text-[9px] text-muted-foreground uppercase font-bold">Crescimento</p>
          <p className={`text-xs font-bold ${metrics.growth >= 0 ? 'text-emerald-600' : 'text-red-600'}`}>
            {metrics.growth >= 0 ? '+' : ''}{formatCurrency(metrics.growth)}
          </p>
        </div>
      </div>

      <div className="bg-card border border-border rounded-3xl p-4 space-y-4">
        <div className="flex items-center justify-between">
          <p className="font-bold text-sm">Fluxo de Caixa</p>
          <div className="flex gap-3 text-[10px]">
            <div className="flex items-center gap-1"><div className="h-2 w-2 rounded-full bg-emerald-500" /> Entradas</div>
            <div className="flex items-center gap-1"><div className="h-2 w-2 rounded-full bg-red-500" /> Saídas</div>
          </div>
        </div>
        <div className="h-48 w-full">
          <ResponsiveContainer width="100%" height="100%">
            <AreaChart data={chartData}>
              <defs>
                <linearGradient id="colorEntries" x1="0" y1="0" x2="0" y2="1">
                  <stop offset="5%" stopColor="#10b981" stopOpacity={0.3}/>
                  <stop offset="95%" stopColor="#10b981" stopOpacity={0}/>
                </linearGradient>
                <linearGradient id="colorExits" x1="0" y1="0" x2="0" y2="1">
                  <stop offset="5%" stopColor="#ef4444" stopOpacity={0.3}/>
                  <stop offset="95%" stopColor="#ef4444" stopOpacity={0}/>
                </linearGradient>
              </defs>
              <CartesianGrid strokeDasharray="3 3" vertical={false} stroke="#f0f0f0" />
              <XAxis dataKey="date" fontSize={10} axisLine={false} tickLine={false} />
              <YAxis fontSize={10} axisLine={false} tickLine={false} tickFormatter={(v) => `R$${v}`} />
              <Tooltip 
                contentStyle={{ borderRadius: '12px', border: 'none', boxShadow: '0 4px 12px rgba(0,0,0,0.1)' }}
                formatter={(v: number) => [formatCurrency(v), '']}
              />
              <Area type="monotone" dataKey="entries" stroke="#10b981" fillOpacity={1} fill="url(#colorEntries)" strokeWidth={2} />
              <Area type="monotone" dataKey="exits" stroke="#ef4444" fillOpacity={1} fill="url(#colorExits)" strokeWidth={2} />
            </AreaChart>
          </ResponsiveContainer>
        </div>
      </div>

      <div className="space-y-3">
        <p className="text-xs font-bold text-muted-foreground uppercase px-1">Indicadores do Período</p>
        <div className="grid grid-cols-3 gap-3">
          <div className="bg-secondary/50 p-4 rounded-3xl text-center space-y-1">
            <Users className="h-5 w-5 mx-auto text-primary opacity-50" />
            <p className="text-xl font-bold">{metrics.activeClients}</p>
            <p className="text-[8px] text-muted-foreground uppercase font-bold">Clientes Ativos</p>
          </div>
          <div className="bg-secondary/50 p-4 rounded-3xl text-center space-y-1">
            <AlertCircle className="h-5 w-5 mx-auto text-red-500 opacity-50" />
            <p className="text-xl font-bold text-red-600">{metrics.delinquentClients}</p>
            <p className="text-[8px] text-muted-foreground uppercase font-bold">Inadimplentes</p>
          </div>
          <div className="bg-secondary/50 p-4 rounded-3xl text-center space-y-1">
            <HandCoins className="h-5 w-5 mx-auto text-emerald-500 opacity-50" />
            <p className="text-xl font-bold">{metrics.activeLoansCount}</p>
            <p className="text-[8px] text-muted-foreground uppercase font-bold">Empréstimos</p>
          </div>
        </div>
      </div>

      <div className="bg-card border border-border rounded-3xl p-4 space-y-3">
        <p className="font-bold text-sm mb-2">Resumo Financeiro</p>
        <div className="space-y-2">
          <div className="flex justify-between items-center text-sm">
            <span className="text-muted-foreground">Entradas (Pagamentos)</span>
            <span className="font-bold text-emerald-600">{formatCurrency(metrics.entries)}</span>
          </div>
          <div className="flex justify-between items-center text-sm">
            <span className="text-muted-foreground">Saídas (Empréstimos + Retiradas)</span>
            <span className="font-bold text-red-600">{formatCurrency(metrics.exits)}</span>
          </div>
          <div className="flex justify-between items-center text-sm">
            <span className="text-muted-foreground">Despesas (Retiradas)</span>
            <span className="font-bold text-amber-600">{formatCurrency(metrics.expenses)}</span>
          </div>
          <div className="pt-2 border-t border-border flex justify-between items-center">
            <span className="font-bold text-sm">Resultado Líquido</span>
            <span className={`font-bold ${metrics.growth >= 0 ? 'text-emerald-600' : 'text-red-600'}`}>
              {formatCurrency(metrics.growth)}
            </span>
          </div>
        </div>
      </div>
    </div>
  );
});

const SettingsScreen = memo(({ 
  user, 
  userProfile, 
  onUpdateProfile, 
  onLogout,
  onBack,
  onOpenPinModal,
  onSetPin
}: { 
  user: User, 
  userProfile: UserProfile | null, 
  onUpdateProfile: (data: Partial<UserProfile>) => Promise<void>,
  onLogout: () => void,
  onBack: () => void,
  onOpenPinModal: (onVerify: (p: string) => void) => void,
  onSetPin: (pin: string) => void
}) => {
  const [isChangingPassword, setIsChangingPassword] = useState(false);
  const [isChangingEmail, setIsChangingEmail] = useState(false);
  const [passwords, setPasswords] = useState({ current: '', new: '', confirm: '' });
  const [newEmail, setNewEmail] = useState(user.email || '');
  const [displayName, setDisplayName] = useState(userProfile?.displayName || '');
  const [loading, setLoading] = useState(false);
  const [showLegal, setShowLegal] = useState<'privacy' | 'terms' | null>(null);

  const handleSaveProfile = async () => {
    setLoading(true);
    try {
      await onUpdateProfile({ displayName });
      await updateProfile(user, { displayName });
      toast.success("Perfil atualizado!");
    } catch (err) {
      toast.error("Erro ao atualizar perfil");
    } finally {
      setLoading(false);
    }
  };

  const handlePhotoUpload = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;

    setLoading(true);
    try {
      const compressed = await imageCompression(file, { maxSizeMB: 0.5, maxWidthOrHeight: 500 });
      const storageRef = ref(storage, `profiles/${user.uid}`);
      await uploadBytes(storageRef, compressed);
      const url = await getDownloadURL(storageRef);
      
      await onUpdateProfile({ photoURL: url });
      await updateProfile(user, { photoURL: url });
      toast.success("Foto atualizada!");
    } catch (err) {
      toast.error("Erro ao carregar foto");
    } finally {
      setLoading(false);
    }
  };

  const handleChangePassword = async () => {
    if (passwords.new !== passwords.confirm) {
      toast.error("As senhas não coincidem");
      return;
    }
    if (passwords.new.length < 6) {
      toast.error("A senha deve ter pelo menos 6 caracteres");
      return;
    }

    setLoading(true);
    try {
      const credential = EmailAuthProvider.credential(user.email!, passwords.current);
      await reauthenticateWithCredential(user, credential);
      await updatePassword(user, passwords.new);
      toast.success("Senha alterada com sucesso!");
      setIsChangingPassword(false);
      setPasswords({ current: '', new: '', confirm: '' });
    } catch (err: any) {
      if (err.code === 'auth/wrong-password') {
        toast.error("Senha atual incorreta");
      } else {
        toast.error("Erro ao alterar senha. Tente sair e entrar novamente.");
      }
    } finally {
      setLoading(false);
    }
  };

  const handleChangeEmail = async () => {
    setLoading(true);
    try {
      // Re-auth might be needed here too, but for simplicity:
      await updateEmail(user, newEmail);
      await onUpdateProfile({ email: newEmail });
      toast.success("E-mail atualizado!");
      setIsChangingEmail(false);
    } catch (err: any) {
      toast.error("Erro ao atualizar e-mail. Re-autenticação necessária.");
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="space-y-6 pb-24">
      <div className="flex items-center gap-4 mb-2">
        <Button variant="ghost" size="icon" onClick={onBack} className="rounded-full">
          <ChevronLeft className="h-6 w-6" />
        </Button>
        <h2 className="text-xl font-bold">Configurações</h2>
      </div>

      {/* Perfil */}
      <section className="space-y-4">
        <h3 className="text-xs font-bold text-muted-foreground uppercase tracking-wider px-1">Perfil</h3>
        <div className="bg-card border border-border rounded-3xl p-5 space-y-4">
          <div className="flex flex-col items-center gap-3">
            <div className="relative group">
              <div className="h-24 w-24 rounded-full bg-secondary overflow-hidden border-2 border-primary/20">
                {userProfile?.photoURL ? (
                  <img src={userProfile.photoURL} alt="Profile" className="h-full w-full object-cover" referrerPolicy="no-referrer" />
                ) : (
                  <div className="h-full w-full flex items-center justify-center text-muted-foreground">
                    <UserCircle className="h-16 w-16" />
                  </div>
                )}
              </div>
              <label className="absolute bottom-0 right-0 h-8 w-8 bg-primary text-primary-foreground rounded-full flex items-center justify-center cursor-pointer shadow-lg hover:scale-110 transition-transform">
                <Camera className="h-4 w-4" />
                <input type="file" className="hidden" accept="image/*" onChange={handlePhotoUpload} disabled={loading} />
              </label>
            </div>
            <div className="text-center">
              <p className="font-bold">{userProfile?.displayName || "Usuário"}</p>
              <p className="text-xs text-muted-foreground">{user.email}</p>
            </div>
          </div>

          <div className="space-y-3 pt-2">
            <div className="space-y-1.5">
              <Label className="text-xs ml-1">Nome de Exibição</Label>
              <div className="flex gap-2">
                <Input 
                  value={displayName} 
                  onChange={e => setDisplayName(e.target.value)} 
                  placeholder="Seu nome"
                  className="rounded-xl h-10"
                />
                <Button size="sm" onClick={handleSaveProfile} disabled={loading || displayName === userProfile?.displayName} className="rounded-xl px-4">
                  Salvar
                </Button>
              </div>
            </div>

            <div className="space-y-1.5">
              <Label className="text-xs ml-1">E-mail</Label>
              {isChangingEmail ? (
                <div className="flex gap-2">
                  <Input 
                    value={newEmail} 
                    onChange={e => setNewEmail(e.target.value)} 
                    placeholder="Novo e-mail"
                    className="rounded-xl h-10"
                  />
                  <Button size="sm" onClick={handleChangeEmail} disabled={loading} className="rounded-xl px-4">
                    OK
                  </Button>
                  <Button size="sm" variant="ghost" onClick={() => setIsChangingEmail(false)} className="rounded-xl">
                    <X className="h-4 w-4" />
                  </Button>
                </div>
              ) : (
                <div className="flex items-center justify-between p-3 bg-secondary/30 rounded-xl border border-border">
                  <span className="text-sm">{user.email}</span>
                  <Button variant="ghost" size="sm" onClick={() => setIsChangingEmail(true)} className="h-7 text-xs text-primary">Alterar</Button>
                </div>
              )}
            </div>
          </div>
        </div>
      </section>

      {/* Segurança */}
      <section className="space-y-4">
        <h3 className="text-xs font-bold text-muted-foreground uppercase tracking-wider px-1">Segurança</h3>
        <div className="bg-card border border-border rounded-3xl p-5 space-y-4">
          <div className="space-y-3">
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-3">
                <div className="h-9 w-9 bg-amber-100 text-amber-600 rounded-xl flex items-center justify-center">
                  <Lock className="h-5 w-5" />
                </div>
                <div>
                  <p className="text-sm font-bold">Senha da Conta</p>
                  <p className="text-[10px] text-muted-foreground">Mantenha sua conta protegida</p>
                </div>
              </div>
              <Button variant="outline" size="sm" onClick={() => setIsChangingPassword(!isChangingPassword)} className="rounded-xl">
                {isChangingPassword ? "Cancelar" : "Alterar"}
              </Button>
            </div>

            {isChangingPassword && (
              <div className="space-y-3 pt-2 animate-in slide-in-from-top-2 duration-300">
                <Input 
                  type="password" 
                  placeholder="Senha atual" 
                  value={passwords.current} 
                  onChange={e => setPasswords(p => ({ ...p, current: e.target.value }))}
                  className="rounded-xl"
                />
                <Input 
                  type="password" 
                  placeholder="Nova senha" 
                  value={passwords.new} 
                  onChange={e => setPasswords(p => ({ ...p, new: e.target.value }))}
                  className="rounded-xl"
                />
                <Input 
                  type="password" 
                  placeholder="Confirmar nova senha" 
                  value={passwords.confirm} 
                  onChange={e => setPasswords(p => ({ ...p, confirm: e.target.value }))}
                  className="rounded-xl"
                />
                <Button className="w-full rounded-xl" onClick={handleChangePassword} disabled={loading}>
                  Confirmar Alteração
                </Button>
              </div>
            )}

            <div className="flex items-center justify-between pt-2">
              <div className="flex items-center gap-3">
                <div className="h-9 w-9 bg-blue-100 text-blue-600 rounded-xl flex items-center justify-center">
                  <Fingerprint className="h-5 w-5" />
                </div>
                <div>
                  <p className="text-sm font-bold">Biometria / Face ID</p>
                  <p className="text-[10px] text-muted-foreground">Acesso rápido e seguro</p>
                </div>
              </div>
              <Checkbox 
                checked={userProfile?.biometricsEnabled} 
                onCheckedChange={(checked) => onUpdateProfile({ biometricsEnabled: !!checked })}
                className="h-6 w-6 rounded-lg"
              />
            </div>

            <div className="flex items-center justify-between pt-2">
              <div className="flex items-center gap-3">
                <div className="h-9 w-9 bg-emerald-100 text-emerald-600 rounded-xl flex items-center justify-center">
                  <Key className="h-5 w-5" />
                </div>
                <div>
                  <p className="text-sm font-bold">Gerenciar PIN</p>
                  <p className="text-[10px] text-muted-foreground">{userProfile?.pin ? `Ativo (${userProfile.pin.length} dígitos)` : "Desativado"}</p>
                </div>
              </div>
              <div className="flex gap-2">
                {userProfile?.pin && (
                  <Button variant="ghost" size="sm" onClick={() => onUpdateProfile({ pin: "" })} className="text-red-600 text-[10px] h-7 px-2 font-bold uppercase">Desativar</Button>
                )}
                <Button variant="outline" size="sm" onClick={() => onOpenPinModal(onSetPin)} className="rounded-xl h-8 px-3 text-xs">
                  {userProfile?.pin ? "Alterar" : "Ativar"}
                </Button>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Tema */}
      <section className="space-y-4">
        <h3 className="text-xs font-bold text-muted-foreground uppercase tracking-wider px-1">Tema</h3>
        <div className="bg-card border border-border rounded-3xl p-2 flex gap-1">
          {[
            { id: 'light', label: 'Claro', icon: Sun },
            { id: 'dark', label: 'Escuro', icon: Moon },
            { id: 'system', label: 'Auto', icon: Monitor },
          ].map((t) => (
            <button
              key={t.id}
              onClick={() => onUpdateProfile({ theme: t.id as any })}
              className={`flex-1 flex flex-col items-center gap-2 py-3 rounded-2xl transition-all ${
                userProfile?.theme === t.id 
                ? 'bg-primary text-primary-foreground shadow-md' 
                : 'hover:bg-secondary text-muted-foreground'
              }`}
            >
              <t.icon className="h-5 w-5" />
              <span className="text-[10px] font-bold uppercase">{t.label}</span>
            </button>
          ))}
        </div>
      </section>

      {/* Notificações */}
      <section className="space-y-4">
        <h3 className="text-xs font-bold text-muted-foreground uppercase tracking-wider px-1">Notificações</h3>
        <div className="bg-card border border-border rounded-3xl p-5">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-3">
              <div className={`h-9 w-9 rounded-xl flex items-center justify-center ${userProfile?.notificationsEnabled ? 'bg-emerald-100 text-emerald-600' : 'bg-red-100 text-red-600'}`}>
                {userProfile?.notificationsEnabled ? <Bell className="h-5 w-5" /> : <BellOff className="h-5 w-5" />}
              </div>
              <div>
                <p className="text-sm font-bold">Notificações Push</p>
                <p className="text-[10px] text-muted-foreground">Alertas de vencimento e pagamentos</p>
              </div>
            </div>
            <Checkbox 
              checked={userProfile?.notificationsEnabled} 
              onCheckedChange={(checked) => onUpdateProfile({ notificationsEnabled: !!checked })}
              className="h-6 w-6 rounded-lg"
            />
          </div>
        </div>
      </section>

      {/* Instalação */}
      <section className="space-y-4">
        <h3 className="text-xs font-bold text-muted-foreground uppercase tracking-wider px-1">Instalação</h3>
        <div className="bg-card border border-border rounded-3xl p-5">
           <a 
            href="#" 
            id="btnInstalar"
            onClick={(e) => {
              e.preventDefault();
              alert("FUNCIONOU!");
            }}
            className="block p-3 border border-border rounded-[10px] bg-secondary/20 hover:bg-secondary/40 transition-colors"
          >
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-3">
                <span className="text-xl">📲</span>
                <span className="text-sm font-bold">Adicionar à tela inicial</span>
              </div>
              <ChevronRight className="h-4 w-4 text-muted-foreground" />
            </div>
          </a>
        </div>
      </section>

      {/* Conta */}
      <section className="space-y-4">
        <h3 className="text-xs font-bold text-muted-foreground uppercase tracking-wider px-1">Conta</h3>
        <div className="bg-card border border-border rounded-3xl p-2 space-y-1">
          <button 
            onClick={onLogout}
            className="w-full flex items-center justify-between p-4 hover:bg-secondary/50 rounded-2xl transition-colors text-red-600"
          >
            <div className="flex items-center gap-3">
              <LogOut className="h-5 w-5" />
              <span className="text-sm font-bold">Sair da Conta</span>
            </div>
            <ChevronRight className="h-4 w-4 opacity-50" />
          </button>
          <button 
            onClick={onLogout} // Switch account is basically logout then login
            className="w-full flex items-center justify-between p-4 hover:bg-secondary/50 rounded-2xl transition-colors"
          >
            <div className="flex items-center gap-3">
              <Users className="h-5 w-5" />
              <span className="text-sm font-bold">Trocar de Conta</span>
            </div>
            <ChevronRight className="h-4 w-4 opacity-50" />
          </button>
        </div>
      </section>

      {/* Legal */}
      <section className="space-y-4">
        <h3 className="text-xs font-bold text-muted-foreground uppercase tracking-wider px-1">Legal</h3>
        <div className="bg-card border border-border rounded-3xl p-2 space-y-1">
          <button onClick={() => setShowLegal('privacy')} className="w-full flex items-center justify-between p-4 hover:bg-secondary/50 rounded-2xl transition-colors">
            <div className="flex items-center gap-3">
              <Shield className="h-5 w-5 text-muted-foreground" />
              <span className="text-sm font-bold">Política de Privacidade</span>
            </div>
            <ChevronRight className="h-4 w-4 opacity-50" />
          </button>
          <button onClick={() => setShowLegal('terms')} className="w-full flex items-center justify-between p-4 hover:bg-secondary/50 rounded-2xl transition-colors">
            <div className="flex items-center gap-3">
              <FileText className="h-5 w-5 text-muted-foreground" />
              <span className="text-sm font-bold">Termos de Uso</span>
            </div>
            <ChevronRight className="h-4 w-4 opacity-50" />
          </button>
        </div>
      </section>

      <div className="text-center pt-4">
        <p className="text-[10px] text-muted-foreground uppercase font-bold tracking-widest">Capital Flow v2.1.0</p>
      </div>

      {/* Legal Modals */}
      <Dialog open={!!showLegal} onOpenChange={() => setShowLegal(null)}>
        <DialogContent className="max-w-md rounded-3xl">
          <DialogHeader>
            <DialogTitle>{showLegal === 'privacy' ? 'Política de Privacidade' : 'Termos de Uso'}</DialogTitle>
            <DialogDescription>
              Última atualização: Abril de 2026
            </DialogDescription>
          </DialogHeader>
          <ScrollArea className="h-80 pr-4">
            <div className="text-sm space-y-4 text-muted-foreground">
              <p>Este documento descreve como o Capital Flow gerencia seus dados e as regras de utilização do serviço.</p>
              <h4 className="font-bold text-foreground">1. Coleta de Dados</h4>
              <p>Coletamos informações necessárias para a gestão de seus empréstimos e capitais, incluindo dados de clientes e registros financeiros.</p>
              <h4 className="font-bold text-foreground">2. Segurança</h4>
              <p>Utilizamos criptografia de ponta e serviços seguros do Google Firebase para garantir a integridade de suas informações.</p>
              <h4 className="font-bold text-foreground">3. Responsabilidade</h4>
              <p>O usuário é responsável pela veracidade dos dados inseridos e pela gestão de seus próprios recursos financeiros.</p>
              <p>Ao utilizar este aplicativo, você concorda com todos os termos aqui descritos.</p>
            </div>
          </ScrollArea>
          <Button onClick={() => setShowLegal(null)} className="w-full rounded-xl">Entendido</Button>
        </DialogContent>
      </Dialog>
    </div>
  );
});

function WithdrawalForm({ capitals, onSave, onCancel, generalCapital }: { capitals: Capital[], onSave: (data: any) => void, onCancel: () => void, generalCapital: GeneralCapital | null }) {
  const [form, setForm] = useState({
    amount: "",
    date: format(new Date(), 'yyyy-MM-dd'),
    capitalId: 'app',
    category: "Outros" as Withdrawal['category'],
    description: "",
  });

  const selectedCapital = capitals.find(c => c.id === form.capitalId);

  function handleSave() {
    if (!form.amount || !form.capitalId) { toast.error("Preencha valor e origem."); return; }
    const amount = parseFloat(form.amount);
    
    if (form.capitalId === 'app') {
      if (generalCapital && amount > generalCapital.available_amount) {
        toast.error(`Limite excedido! Disponível no App: ${formatCurrency(generalCapital.available_amount)}`);
        return;
      }
    } else if (selectedCapital && amount > selectedCapital.balance) {
      toast.error(`Limite excedido! Disponível: ${formatCurrency(selectedCapital.balance)}`);
      return;
    }

    onSave({
      ...form,
      amount,
      date: new Date(form.date).toISOString(),
    });
  }

  return (
    <div className="bg-card border border-border rounded-2xl p-4 space-y-4">
      <div className="flex items-center gap-2 text-red-600 mb-2">
        <LogOut className="h-5 w-5 rotate-90" />
        <p className="font-bold">Nova Retirada</p>
      </div>
      
      <div className="grid grid-cols-2 gap-3">
        <div className="space-y-1">
          <Label>Valor (R$)</Label>
          <Input type="number" placeholder="0.00" className="rounded-xl h-11" value={form.amount} onChange={e => setForm(f => ({ ...f, amount: e.target.value }))} />
        </div>
        <div className="space-y-1">
          <Label>Data</Label>
          <Input type="date" className="rounded-xl h-11" value={form.date} onChange={e => setForm(f => ({ ...f, date: e.target.value }))} />
        </div>
      </div>

      <div className="space-y-1">
        <Label>Origem da Retirada</Label>
        <Select value={form.capitalId} onValueChange={v => setForm(f => ({ ...f, capitalId: v }))}>
          <SelectTrigger className="rounded-xl h-11">
            <SelectValue placeholder="Selecione a origem" />
          </SelectTrigger>
          <SelectContent>
            <SelectItem value="app">Capital do App (Geral)</SelectItem>
            {capitals.map(c => (
              <SelectItem key={c.id} value={c.id}>{c.name} (Saldo: {formatCurrency(c.balance)})</SelectItem>
            ))}
          </SelectContent>
        </Select>
        <p className="text-[10px] text-muted-foreground mt-1">
          {form.capitalId === 'app' 
            ? `Retirada direta do caixa geral. Não altera saldos individuais. (Disponível: ${formatCurrency(generalCapital?.available_amount || 0)})`
            : `Retirada do saldo individual e do capital geral. (Disponível no App: ${formatCurrency(generalCapital?.available_amount || 0)})`
          }
        </p>
      </div>

      <div className="space-y-1">
        <Label>Categoria</Label>
        <Select value={form.category} onValueChange={(v: any) => setForm(f => ({ ...f, category: v }))}>
          <SelectTrigger className="rounded-xl h-11">
            <SelectValue placeholder="Selecione a categoria" />
          </SelectTrigger>
          <SelectContent>
            {["Alimentação", "Transporte", "Pessoal", "Emergência", "Outros"].map(cat => (
              <SelectItem key={cat} value={cat}>{cat}</SelectItem>
            ))}
          </SelectContent>
        </Select>
      </div>

      <div className="space-y-1">
        <Label>Descrição (Opcional)</Label>
        <Input placeholder="Ex: Almoço de domingo" className="rounded-xl h-11" value={form.description} onChange={e => setForm(f => ({ ...f, description: e.target.value }))} />
      </div>

      <div className="flex gap-2 pt-2">
        <Button className="flex-1 rounded-xl bg-red-600 hover:bg-red-700" onClick={handleSave}>Confirmar Retirada</Button>
        <Button variant="outline" className="rounded-xl" onClick={onCancel}>Cancelar</Button>
      </div>
    </div>
  );
}

function WithdrawalCard({ withdrawal, capitalName }: { key?: React.Key, withdrawal: Withdrawal, capitalName: string }) {
  const isApp = withdrawal.capitalId === 'app';
  const isJoao = capitalName.toLowerCase().includes('joão');
  const isVanessa = capitalName.toLowerCase().includes('vanessa');

  const bgColor = isApp ? 'bg-muted/50' : isJoao ? 'bg-blue-50' : isVanessa ? 'bg-pink-50' : 'bg-red-50';
  const textColor = isApp ? 'text-muted-foreground' : isJoao ? 'text-blue-600' : isVanessa ? 'text-pink-600' : 'text-red-600';
  const label = isApp ? 'Capital App' : capitalName;

  return (
    <div className="bg-card border border-border rounded-2xl p-4 flex items-center justify-between">
      <div className="flex items-center gap-3">
        <div className={`h-10 w-10 ${bgColor} rounded-xl flex items-center justify-center`}>
          <LogOut className={`h-5 w-5 ${textColor} rotate-90`} />
        </div>
        <div>
          <p className="font-bold text-sm">{withdrawal.category}</p>
          <p className="text-[10px] text-muted-foreground">{format(new Date(withdrawal.date), 'dd/MM/yyyy')} • {label}</p>
        </div>
      </div>
      <div className="text-right">
        <p className={`font-bold ${textColor}`}>-{formatCurrency(withdrawal.amount)}</p>
        {withdrawal.description && <p className="text-[10px] text-muted-foreground truncate max-w-[100px]">{withdrawal.description}</p>}
      </div>
    </div>
  );
}

function DocItem({ label, url, onUpload, loading }: { label: string, url?: string, onUpload: (e: any) => void, loading: boolean }) {
  return (
    <div className="bg-card border border-border rounded-2xl p-4 flex items-center justify-between">
      <div className="flex items-center gap-3">
        <div className="h-10 w-10 bg-secondary rounded-xl flex items-center justify-center">
          <FileText className="h-5 w-5 text-muted-foreground" />
        </div>
        <div>
          <p className="text-sm font-bold">{label}</p>
          <p className="text-[10px] text-muted-foreground">{url ? "Documento enviado" : "Pendente"}</p>
        </div>
      </div>
      <div className="flex gap-2">
        {url ? (
          <Button size="sm" variant="outline" className="h-8 rounded-lg" onClick={() => window.open(url, '_blank')}>
            <Maximize2 className="h-3.5 w-3.5" />
          </Button>
        ) : (
          <label className="h-8 px-3 bg-primary text-primary-foreground rounded-lg text-xs font-bold flex items-center cursor-pointer hover:bg-primary/90 transition-colors">
            {loading ? <div className="h-3 w-3 border-2 border-primary-foreground/20 border-t-primary-foreground rounded-full animate-spin" /> : <Upload className="h-3.5 w-3.5 mr-1" />}
            {loading ? "" : "Enviar"}
            <input type="file" className="hidden" onChange={onUpload} disabled={loading} />
          </label>
        )}
      </div>
    </div>
  );
}

interface PendingFile {
  file: File;
  preview: string;
  type: 'photo' | 'document';
  category?: string;
}

interface ClientFormProps {
  key?: React.Key;
  initial?: Client | null;
  onSave: (data: any, files?: PendingFile[]) => void;
  onCancel: () => void;
}

function ClientForm({ initial, onSave, onCancel }: ClientFormProps) {
  const [form, setForm] = useState({
    name: initial?.name || "",
    phone: initial?.phone || "",
    email: initial?.email || "",
    cpf: initial?.cpf || "",
    observations: initial?.observations || "",
    address: initial?.address || "",
    addressNumber: initial?.addressNumber || "",
    neighborhood: initial?.neighborhood || "",
    city: initial?.city || "",
    mapsLink: initial?.mapsLink || "",
  });

  const [pendingFiles, setPendingFiles] = useState<PendingFile[]>([]);
  const [enlargedImage, setEnlargedImage] = useState<string | null>(null);

  function handleFileSelect(e: React.ChangeEvent<HTMLInputElement>, type: 'photo' | 'document') {
    const files = e.target.files;
    if (!files) return;

    const newPending: PendingFile[] = [];
    for (let i = 0; i < files.length; i++) {
      const file = files[i];
      const preview = URL.createObjectURL(file);
      newPending.push({ file, preview, type, category: type === 'document' ? 'Outros' : undefined });
    }

    setPendingFiles(prev => [...prev, ...newPending]);
    // Reset input
    e.target.value = '';
  }

  function removePendingFile(index: number) {
    setPendingFiles(prev => {
      const updated = [...prev];
      URL.revokeObjectURL(updated[index].preview);
      updated.splice(index, 1);
      return updated;
    });
  }

  function handleSave() {
    if (!form.name) { toast.error("Nome é obrigatório."); return; }
    onSave(form, pendingFiles);
  }

  return (
    <div className="bg-card border border-border rounded-2xl p-4 space-y-4 max-h-[80vh] overflow-y-auto">
      <p className="font-bold text-lg">{initial ? "Editar Cliente" : "Novo Cliente"}</p>
      
      <div className="space-y-3">
        <div className="grid grid-cols-2 gap-3">
          <div className="space-y-1">
            <Label>Nome Completo</Label>
            <Input placeholder="Ex: Maria Silva" className="rounded-xl" value={form.name} onChange={e => setForm(f => ({ ...f, name: e.target.value }))} />
          </div>
          <div className="space-y-1">
            <Label>WhatsApp</Label>
            <Input placeholder="55..." className="rounded-xl" value={form.phone} onChange={e => setForm(f => ({ ...f, phone: e.target.value }))} />
          </div>
        </div>

        <div className="grid grid-cols-2 gap-3">
          <div className="space-y-1">
            <Label>Email</Label>
            <Input type="email" placeholder="email@exemplo.com" className="rounded-xl" value={form.email} onChange={e => setForm(f => ({ ...f, email: e.target.value }))} />
          </div>
          <div className="space-y-1">
            <Label>CPF (Opcional)</Label>
            <Input placeholder="000.000.000-00" className="rounded-xl" value={form.cpf} onChange={e => setForm(f => ({ ...f, cpf: e.target.value }))} />
          </div>
        </div>

        <div className="space-y-1">
          <Label>Observações</Label>
          <Input placeholder="Notas sobre o cliente..." className="rounded-xl" value={form.observations} onChange={e => setForm(f => ({ ...f, observations: e.target.value }))} />
        </div>

        <div className="grid grid-cols-3 gap-3">
          <div className="col-span-2 space-y-1">
            <Label>Rua</Label>
            <Input placeholder="Rua..." className="rounded-xl" value={form.address} onChange={e => setForm(f => ({ ...f, address: e.target.value }))} />
          </div>
          <div className="space-y-1">
            <Label>Nº</Label>
            <Input placeholder="123" className="rounded-xl" value={form.addressNumber} onChange={e => setForm(f => ({ ...f, addressNumber: e.target.value }))} />
          </div>
        </div>

        <div className="grid grid-cols-2 gap-3">
          <div className="space-y-1">
            <Label>Bairro</Label>
            <Input placeholder="Bairro..." className="rounded-xl" value={form.neighborhood} onChange={e => setForm(f => ({ ...f, neighborhood: e.target.value }))} />
          </div>
          <div className="space-y-1">
            <Label>Cidade</Label>
            <Input placeholder="Cidade..." className="rounded-xl" value={form.city} onChange={e => setForm(f => ({ ...f, city: e.target.value }))} />
          </div>
        </div>

        <div className="space-y-1">
          <Label>Link Google Maps (Opcional)</Label>
          <Input placeholder="https://goo.gl/maps/..." className="rounded-xl" value={form.mapsLink} onChange={e => setForm(f => ({ ...f, mapsLink: e.target.value }))} />
        </div>

        <div className="pt-4 border-t border-border space-y-4">
          <div className="flex items-center gap-2 text-primary">
            <FolderOpen className="h-5 w-5" />
            <p className="font-bold text-sm">Fotos e Documentos</p>
          </div>

          <div className="grid grid-cols-2 gap-3">
            <label className="flex flex-col items-center justify-center p-4 border-2 border-dashed border-border rounded-2xl cursor-pointer hover:bg-secondary/50 transition-colors">
              <ImagePlus className="h-6 w-6 text-muted-foreground mb-1" />
              <span className="text-[10px] font-bold text-muted-foreground">Adicionar Foto</span>
              <input type="file" accept="image/*" multiple className="hidden" onChange={e => handleFileSelect(e, 'photo')} />
            </label>
            <label className="flex flex-col items-center justify-center p-4 border-2 border-dashed border-border rounded-2xl cursor-pointer hover:bg-secondary/50 transition-colors">
              <FilePlus className="h-6 w-6 text-muted-foreground mb-1" />
              <span className="text-[10px] font-bold text-muted-foreground">Adicionar Documento</span>
              <input type="file" accept="image/*,application/pdf" multiple className="hidden" onChange={e => handleFileSelect(e, 'document')} />
            </label>
          </div>

          {pendingFiles.length > 0 && (
            <div className="grid grid-cols-4 gap-2">
              {pendingFiles.map((pf, idx) => (
                <div key={idx} className="relative aspect-square rounded-xl bg-secondary overflow-hidden group">
                  {pf.file.type.startsWith('image/') ? (
                    <img 
                      src={pf.preview} 
                      className="h-full w-full object-cover cursor-pointer" 
                      onClick={() => setEnlargedImage(pf.preview)}
                    />
                  ) : (
                    <div className="h-full w-full flex items-center justify-center">
                      <FileText className="h-8 w-8 text-muted-foreground" />
                    </div>
                  )}
                  <button 
                    className="absolute top-1 right-1 h-6 w-6 bg-black/50 rounded-full flex items-center justify-center text-white opacity-0 group-hover:opacity-100 transition-opacity"
                    onClick={() => removePendingFile(idx)}
                  >
                    <X className="h-3 w-3" />
                  </button>
                  <div className="absolute bottom-0 left-0 right-0 bg-black/40 py-0.5 px-1">
                    <p className="text-[8px] text-white truncate text-center">{pf.type === 'photo' ? 'Foto' : 'Doc'}</p>
                  </div>
                </div>
              ))}
            </div>
          )}
        </div>
      </div>

      <div className="flex gap-2 pt-4 border-t border-border">
        <Button className="flex-1 rounded-xl h-12 text-lg" onClick={handleSave}><Check className="h-5 w-5 mr-2" /> Salvar Cliente</Button>
        <Button variant="outline" className="rounded-xl h-12 px-6" onClick={onCancel}><X className="h-5 w-5" /></Button>
      </div>

      {enlargedImage && (
        <Dialog open={!!enlargedImage} onOpenChange={() => setEnlargedImage(null)}>
          <DialogContent className="max-w-3xl p-0 overflow-hidden bg-black/95 border-none rounded-3xl">
            <div className="relative aspect-auto max-h-[80vh] flex items-center justify-center p-4">
              <img src={enlargedImage} className="max-w-full max-h-full object-contain rounded-xl" referrerPolicy="no-referrer" />
              <Button 
                variant="ghost" 
                size="icon" 
                className="absolute top-4 right-4 text-white hover:bg-white/20 rounded-full"
                onClick={() => setEnlargedImage(null)}
              >
                <X className="h-6 w-6" />
              </Button>
            </div>
          </DialogContent>
        </Dialog>
      )}
    </div>
  );
}

function ClientDetails({ client, files, loans, onUpdate, onAddFile, onDeleteFile, onBack }: { client: Client, files: ClientFile[], loans: Loan[], onUpdate: (id: string, data: any) => void, onAddFile: (clientId: string, data: any) => void, onDeleteFile: (clientId: string, fileId: string) => void, onBack: () => void }) {
  const [uploading, setUploading] = useState<string | null>(null);
  const [validating, setValidating] = useState(false);
  const [validationStatus, setValidationStatus] = useState<'idle' | 'success' | 'error'>('idle');
  const [showFileForm, setShowFileForm] = useState(false);
  const [selectedFile, setSelectedFile] = useState<ClientFile | null>(null);
  const [fileSearch, setFileSearch] = useState("");
  const [sendingSummary, setSendingSummary] = useState<string | null>(null);

  const clientLoans = loans.filter(l => l.clientName === client.name && l.status === 'active');

  async function handleSendSummary(loan: Loan, period: 'daily' | 'weekly' | 'monthly' | 'all') {
    setSendingSummary(loan.id);
    try {
      const q = query(collection(db, `loans/${loan.id}/installments`), orderBy("number", "asc"));
      const snap = await getDocs(q);
      const insts = snap.docs.map(d => d.data());
      
      const message = getWhatsAppSummaryMessage(client.name, loan, insts, period);
      const encoded = encodeURIComponent(message);
      window.open(`https://wa.me/${client.phone.replace(/\D/g, '')}?text=${encoded}`, '_blank');
      toast.success("Resumo gerado!");
    } catch (err) {
      console.error(err);
      toast.error("Erro ao gerar resumo.");
    } finally {
      setSendingSummary(null);
    }
  }

  const categories = ['Contratos', 'Documentos', 'Outros'] as const;
  const requiredDocs = ['RG', 'CPF', 'Comprovante de residência'];
  
  const missingDocs = requiredDocs.filter(docType => 
    !files.some(f => f.type === docType)
  );

  async function handleFileUpload(e: React.ChangeEvent<HTMLInputElement>, type: 'profile' | 'photo' | 'rg' | 'cpf' | 'residence' | 'file') {
    const file = e.target.files?.[0];
    if (!file) return "";

    setUploading(type);
    try {
      const path = `clients/${client.id}/${type}_${Date.now()}`;
      const url = await uploadImage(file, path);

      if (type === 'profile') {
        onUpdate(client.id, { profilePhotoUrl: url, faceRegistered: true });
      } else if (type === 'photo') {
        const photos = [...(client.photos || []), url];
        onUpdate(client.id, { photos });
      } else if (type !== 'file') {
        const field = type === 'rg' ? 'docRgUrl' : type === 'cpf' ? 'docCpfUrl' : 'docResidenceUrl';
        onUpdate(client.id, { [field]: url });
      }
      toast.success("Upload concluído!");
      return url;
    } catch (err) {
      console.error(err);
      toast.error("Erro no upload.");
      return "";
    } finally {
      setUploading(null);
    }
  }

  function simulateValidation() {
    if (!client.profilePhotoUrl) {
      toast.error("Cadastre uma foto de perfil primeiro.");
      return;
    }
    setValidating(true);
    setValidationStatus('idle');
    setTimeout(() => {
      setValidating(false);
      setValidationStatus('success');
      toast.success("Identidade confirmada!");
    }, 2000);
  }

  return (
    <div className="space-y-6 pb-20">
      <div className="flex items-center gap-2">
        <Button variant="ghost" size="sm" onClick={onBack}><ArrowLeft className="h-4 w-4" /></Button>
        <h2 className="font-bold text-lg">Perfil do Cliente</h2>
      </div>

      {missingDocs.length > 0 && (
        <div className="bg-amber-50 border border-amber-200 p-4 rounded-2xl flex items-center gap-3 animate-pulse">
          <AlertCircle className="h-6 w-6 text-amber-600" />
          <div>
            <p className="text-sm font-bold text-amber-800">Documentos Pendentes!</p>
            <p className="text-[10px] text-amber-700">Faltando: {missingDocs.join(', ')}</p>
          </div>
        </div>
      )}

      <div className="bg-card border border-border rounded-3xl p-6 flex flex-col items-center text-center space-y-4">
        <div className="relative">
          <div className="h-24 w-24 rounded-full bg-secondary overflow-hidden border-4 border-background shadow-sm">
            {client.profilePhotoUrl ? (
              <img src={client.profilePhotoUrl} alt={client.name} className="h-full w-full object-cover" referrerPolicy="no-referrer" />
            ) : (
              <div className="h-full w-full flex items-center justify-center text-muted-foreground"><UserIcon className="h-10 w-10" /></div>
            )}
          </div>
          <label className="absolute bottom-0 right-0 h-8 w-8 bg-primary rounded-full flex items-center justify-center cursor-pointer shadow-md hover:scale-110 transition-transform">
            <Camera className="h-4 w-4 text-primary-foreground" />
            <input type="file" accept="image/*" className="hidden" onChange={e => handleFileUpload(e, 'profile')} disabled={!!uploading} />
          </label>
        </div>
        
        <div>
          <h3 className="font-bold text-xl">{client.name}</h3>
          <p className="text-sm text-muted-foreground">{client.phone}</p>
        </div>

        {clientLoans.length > 0 && (
          <div className="w-full space-y-3 pt-2">
            {clientLoans.map(loan => (
              <div key={loan.id} className="bg-emerald-50 border border-emerald-100 p-4 rounded-2xl space-y-3">
                <div className="flex justify-between items-start">
                  <div className="text-left">
                    <p className="text-xs font-bold text-emerald-900 uppercase">Resumo de Empréstimo</p>
                    <p className="text-[10px] text-emerald-700">{formatCurrency(loan.totalAmount)} • {loan.installmentsCount}x</p>
                  </div>
                  <div className="h-8 w-8 bg-emerald-500 rounded-lg flex items-center justify-center">
                    <MessageCircle className="h-4 w-4 text-white" />
                  </div>
                </div>
                
                <div className="grid grid-cols-3 gap-2">
                  {(['daily', 'weekly', 'monthly'] as const).map(p => (
                    <Button 
                      key={p}
                      size="sm" 
                      variant="outline" 
                      className="h-8 rounded-xl text-[10px] bg-white border-emerald-200 text-emerald-700 hover:bg-emerald-100"
                      onClick={() => handleSendSummary(loan, p)}
                      disabled={!!sendingSummary}
                    >
                      {sendingSummary === loan.id ? <div className="h-3 w-3 border-2 border-emerald-500/20 border-t-emerald-500 rounded-full animate-spin" /> : (p === 'daily' ? 'Diário' : p === 'weekly' ? 'Semanal' : 'Mensal')}
                    </Button>
                  ))}
                </div>
                
                <Button 
                  className="w-full rounded-xl gap-2 bg-emerald-600 hover:bg-emerald-700 text-white h-12 text-base font-bold shadow-lg shadow-emerald-200" 
                  onClick={() => handleSendSummary(loan, 'all')}
                  disabled={!!sendingSummary}
                >
                  {sendingSummary === loan.id ? <div className="h-5 w-5 border-2 border-white/20 border-t-white rounded-full animate-spin" /> : <MessageCircle className="h-5 w-5" />}
                  Enviar resumo via WhatsApp
                </Button>
              </div>
            ))}
          </div>
        )}

        {(client.address || client.city) && (
          <div className="w-full bg-secondary/50 p-4 rounded-2xl text-left space-y-3">
            <div className="flex items-start gap-3">
              <MapPin className="h-5 w-5 text-primary shrink-0 mt-0.5" />
              <div>
                <p className="text-sm font-bold">Endereço</p>
                <p className="text-xs text-muted-foreground">
                  {client.address}{client.addressNumber ? `, ${client.addressNumber}` : ''}
                  <br />
                  {client.neighborhood}{client.neighborhood && client.city ? ' - ' : ''}{client.city}
                </p>
              </div>
            </div>
            <Button 
              className="w-full rounded-xl gap-2 bg-primary hover:bg-primary/90" 
              onClick={() => {
                if (client.mapsLink) {
                  window.open(client.mapsLink, '_blank');
                } else {
                  const query = encodeURIComponent(`${client.address} ${client.addressNumber}, ${client.neighborhood}, ${client.city}`);
                  window.open(`https://www.google.com/maps/search/?api=1&query=${query}`, '_blank');
                }
              }}
            >
              <MapPin className="h-4 w-4" /> Abrir no Mapa
            </Button>
          </div>
        )}

        <div className="flex items-center gap-2 px-3 py-1 bg-secondary rounded-full">
          {client.faceRegistered ? (
            <div className="flex items-center gap-1 text-emerald-600 text-[10px] font-bold">
              <CheckCircle2 className="h-3 w-3" /> FACE REGISTRADA
            </div>
          ) : (
            <div className="flex items-center gap-1 text-muted-foreground text-[10px] font-bold">
              <AlertCircle className="h-3 w-3" /> FACE NÃO REGISTRADA
            </div>
          )}
        </div>

        <Button 
          variant="outline" 
          className="w-full rounded-2xl gap-2" 
          onClick={simulateValidation}
          disabled={validating}
        >
          {validating ? <div className="h-4 w-4 border-2 border-primary/20 border-t-primary rounded-full animate-spin" /> : <Shield className="h-4 w-4 text-primary" />}
          Validar Cliente
        </Button>


        {validationStatus === 'success' && (
          <div className="flex items-center gap-2 text-emerald-600 font-bold text-sm animate-in fade-in slide-in-from-top-1">
            <CheckCircle2 className="h-4 w-4" /> Identidade confirmada
          </div>
        )}
      </div>

      <div className="space-y-3">
        <div className="flex items-center justify-between px-1">
          <p className="font-bold text-sm">Fotos do Cliente</p>
          <label className="text-xs text-primary font-bold cursor-pointer hover:underline">
            Adicionar
            <input type="file" accept="image/*" className="hidden" onChange={e => handleFileUpload(e, 'photo')} disabled={!!uploading} />
          </label>
        </div>
        <div className="grid grid-cols-3 gap-2">
          {client.photos?.map((url, i) => (
            <div key={i} className="aspect-square rounded-xl bg-secondary overflow-hidden relative group">
              <img src={url} className="h-full w-full object-cover" referrerPolicy="no-referrer" />
              <button 
                className="absolute top-1 right-1 h-6 w-6 bg-black/50 rounded-full flex items-center justify-center opacity-0 group-hover:opacity-100 transition-opacity"
                onClick={() => {
                  const photos = client.photos?.filter((_, idx) => idx !== i);
                  onUpdate(client.id, { photos });
                }}
              >
                <Trash2 className="h-3 w-3 text-white" />
              </button>
            </div>
          ))}
          {(!client.photos || client.photos.length === 0) && (
            <div className="col-span-3 py-8 text-center bg-muted/30 rounded-2xl border-2 border-dashed border-border">
              <ImageIcon className="h-8 w-8 text-muted-foreground mx-auto mb-2 opacity-20" />
              <p className="text-xs text-muted-foreground">Nenhuma foto adicionada</p>
            </div>
          )}
        </div>
      </div>

      <div className="space-y-4">
        <div className="flex items-center justify-between px-1">
          <div className="flex items-center gap-2">
            <FolderOpen className="h-5 w-5 text-primary" />
            <p className="font-bold text-sm">Arquivos do Cliente</p>
          </div>
          <Button size="sm" className="rounded-xl h-8 gap-1" onClick={() => setShowFileForm(true)}>
            <Plus className="h-3.5 w-3.5" /> Novo Arquivo
          </Button>
        </div>

        <div className="relative">
          <Search className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground" />
          <Input 
            placeholder="Buscar por tipo (ex: RG, Contrato)..." 
            className="pl-9 rounded-xl h-10" 
            value={fileSearch}
            onChange={e => setFileSearch(e.target.value)}
          />
        </div>

        {categories.map(cat => {
          const catFiles = files.filter(f => f.category === cat && f.type.toLowerCase().includes(fileSearch.toLowerCase()));
          if (catFiles.length === 0 && !fileSearch) return null;
          if (catFiles.length === 0 && fileSearch) return null;

          return (
            <div key={cat} className="space-y-2">
              <p className="text-[10px] font-bold text-muted-foreground uppercase px-1">{cat}</p>
              <div className="grid gap-2">
                {catFiles.map(file => (
                  <div key={file.id} className="bg-card border border-border rounded-2xl p-3 flex items-center justify-between group hover:border-primary/30 transition-colors">
                    <div className="flex items-center gap-3 cursor-pointer" onClick={() => setSelectedFile(file)}>
                      <div className="h-10 w-10 rounded-xl bg-secondary overflow-hidden flex items-center justify-center">
                        {file.url.startsWith('data:image') || file.url.includes('picsum') || file.url.includes('firebasestorage') ? (
                          <img src={file.url} className="h-full w-full object-cover" referrerPolicy="no-referrer" />
                        ) : (
                          <FileText className="h-5 w-5 text-muted-foreground" />
                        )}
                      </div>
                      <div>
                        <p className="text-sm font-bold">{file.type}</p>
                        <p className="text-[10px] text-muted-foreground">{format(new Date(file.uploadDate), 'dd/MM/yyyy')}</p>
                      </div>
                    </div>
                    <div className="flex gap-1">
                      <Button size="icon" variant="ghost" className="h-8 w-8 rounded-lg" onClick={() => window.open(file.url, '_blank')}>
                        <Download className="h-3.5 w-3.5" />
                      </Button>
                      <AlertDialog>
                        <AlertDialogTrigger asChild>
                        <Button size="icon" variant="ghost" className="h-8 w-8 rounded-lg text-red-500 hover:text-red-600 hover:bg-red-50">
                          <Trash2 className="h-3.5 w-3.5" />
                        </Button>
                      </AlertDialogTrigger>
                        <AlertDialogContent>
                          <AlertDialogHeader>
                            <AlertDialogTitle>Excluir arquivo?</AlertDialogTitle>
                            <AlertDialogDescription>Esta ação não pode ser desfeita.</AlertDialogDescription>
                          </AlertDialogHeader>
                          <AlertDialogFooter>
                            <AlertDialogCancel variant="outline">Cancelar</AlertDialogCancel>
                            <AlertDialogAction variant="destructive" onClick={() => onDeleteFile(client.id, file.id)}>Excluir</AlertDialogAction>
                          </AlertDialogFooter>
                        </AlertDialogContent>
                      </AlertDialog>
                    </div>
                  </div>
                ))}
              </div>
            </div>
          );
        })}

        {files.length === 0 && (
          <div className="py-12 text-center bg-muted/20 rounded-3xl border-2 border-dashed border-border">
            <FolderOpen className="h-10 w-10 text-muted-foreground mx-auto mb-2 opacity-20" />
            <p className="text-sm text-muted-foreground">Nenhum arquivo anexado</p>
            <Button variant="link" className="text-xs" onClick={() => setShowFileForm(true)}>Adicionar primeiro arquivo</Button>
          </div>
        )}
      </div>

      {showFileForm && (
        <Dialog open={showFileForm} onOpenChange={setShowFileForm}>
          <DialogContent className="sm:max-w-[425px] rounded-3xl">
            <DialogHeader>
              <DialogTitle>Novo Arquivo</DialogTitle>
              <DialogDescription>Adicione um documento ou foto ao perfil do cliente.</DialogDescription>
            </DialogHeader>
            <FileForm 
              onSave={(data) => {
                onAddFile(client.id, data);
                setShowFileForm(false);
              }} 
              onCancel={() => setShowFileForm(false)}
              uploading={!!uploading}
              onUpload={async (e) => {
                const url = await handleFileUpload(e, 'file');
                setUploading(null);
                return url;
              }}
            />
          </DialogContent>
        </Dialog>
      )}

      {selectedFile && (
        <Dialog open={!!selectedFile} onOpenChange={() => setSelectedFile(null)}>
          <DialogContent className="max-w-3xl p-0 overflow-hidden bg-black/95 border-none rounded-3xl">
            <div className="relative aspect-auto max-h-[80vh] flex items-center justify-center p-4">
              {selectedFile.url.startsWith('data:image') || selectedFile.url.includes('picsum') || selectedFile.url.includes('firebasestorage') ? (
                <img src={selectedFile.url} className="max-w-full max-h-full object-contain rounded-xl" referrerPolicy="no-referrer" />
              ) : (
                <div className="text-white text-center space-y-4">
                  <FileText className="h-20 w-20 mx-auto opacity-50" />
                  <p>Este arquivo não pode ser visualizado diretamente.</p>
                  <Button onClick={() => window.open(selectedFile.url, '_blank')}>Baixar Arquivo</Button>
                </div>
              )}
              <Button 
                variant="ghost" 
                size="icon" 
                className="absolute top-4 right-4 text-white hover:bg-white/20 rounded-full"
                onClick={() => setSelectedFile(null)}
              >
                <X className="h-6 w-6" />
              </Button>
            </div>
            <div className="bg-card p-6 space-y-2">
              <div className="flex items-center justify-between">
                <h3 className="font-bold text-lg">{selectedFile.type}</h3>
                <span className="text-xs text-muted-foreground">{format(new Date(selectedFile.uploadDate), 'dd/MM/yyyy HH:mm')}</span>
              </div>
              <p className="text-xs text-muted-foreground uppercase font-bold">{selectedFile.category}</p>
              {selectedFile.observation && (
                <div className="mt-4 p-3 bg-secondary rounded-xl">
                  <p className="text-sm">{selectedFile.observation}</p>
                </div>
              )}
            </div>
          </DialogContent>
        </Dialog>
      )}

      <div className="p-4 bg-amber-50 border border-amber-100 rounded-2xl flex gap-3">
        <Shield className="h-5 w-5 text-amber-600 shrink-0" />
        <p className="text-[10px] text-amber-800 leading-tight">
          <strong>Aviso de Confidencialidade:</strong> Todas as imagens e documentos são armazenados de forma segura e restritos ao seu acesso.
        </p>
      </div>
    </div>
  );
}

interface ClientCardProps {
  key?: React.Key;
  client: Client;
  onEdit: (c: Client) => void;
  onDelete: (id: string) => void;
  onClick: (c: Client) => void;
}

function FileForm({ onSave, onCancel, uploading, onUpload }: { onSave: (data: any) => void, onCancel: () => void, uploading: boolean, onUpload: (e: any) => Promise<string | undefined> }) {
  const [form, setForm] = useState({
    type: 'Outros' as ClientFile['type'],
    category: 'Documentos' as ClientFile['category'],
    url: '',
    observation: ''
  });

  const docTypes = ['Contrato', 'RG', 'CPF', 'Comprovante de residência', 'Outros'];
  const categories = ['Contratos', 'Documentos', 'Outros'];

  return (
    <div className="space-y-4 py-4">
      <div className="space-y-2">
        <Label>Tipo de Documento</Label>
        <Select value={form.type} onValueChange={(v: any) => setForm(f => ({ ...f, type: v }))}>
          <SelectTrigger className="rounded-xl">
            <SelectValue placeholder="Selecione o tipo" />
          </SelectTrigger>
          <SelectContent>
            {docTypes.map(t => <SelectItem key={t} value={t}>{t}</SelectItem>)}
          </SelectContent>
        </Select>
      </div>

      <div className="space-y-2">
        <Label>Categoria</Label>
        <Select value={form.category} onValueChange={(v: any) => setForm(f => ({ ...f, category: v }))}>
          <SelectTrigger className="rounded-xl">
            <SelectValue placeholder="Selecione a categoria" />
          </SelectTrigger>
          <SelectContent>
            {categories.map(c => <SelectItem key={c} value={c}>{c}</SelectItem>)}
          </SelectContent>
        </Select>
      </div>

      <div className="space-y-2">
        <Label>Arquivo / Foto</Label>
        <div className="flex items-center gap-2">
          <Input 
            type="file" 
            className="rounded-xl hidden" 
            id="file-upload" 
            onChange={async (e) => {
              const url = await onUpload(e);
              if (url) setForm(f => ({ ...f, url }));
            }} 
          />
          <label 
            htmlFor="file-upload" 
            className="flex-1 h-20 border-2 border-dashed border-border rounded-2xl flex flex-col items-center justify-center cursor-pointer hover:bg-secondary/50 transition-colors"
          >
            {uploading ? (
              <div className="h-5 w-5 border-2 border-primary/20 border-t-primary rounded-full animate-spin" />
            ) : form.url ? (
              <div className="flex items-center gap-2 text-emerald-600 font-bold text-xs">
                <CheckCircle2 className="h-4 w-4" /> Arquivo Carregado
              </div>
            ) : (
              <>
                <Upload className="h-5 w-5 text-muted-foreground mb-1" />
                <span className="text-[10px] text-muted-foreground">Clique para enviar</span>
              </>
            )}
          </label>
        </div>
      </div>

      <div className="space-y-2">
        <Label>Observação (Opcional)</Label>
        <Input 
          placeholder="Ex: Documento frente e verso" 
          className="rounded-xl" 
          value={form.observation} 
          onChange={e => setForm(f => ({ ...f, observation: e.target.value }))} 
        />
      </div>

      <div className="flex gap-2 pt-4">
        <Button className="flex-1 rounded-xl" onClick={() => onSave(form)} disabled={!form.url || uploading}>Salvar Arquivo</Button>
        <Button variant="outline" className="rounded-xl" onClick={onCancel}>Cancelar</Button>
      </div>
    </div>
  );
}

const LoanCard = memo(({ loan, onClick }: { loan: Loan, onClick: (l: Loan) => void }) => {
  return (
    <motion.div 
      whileHover={{ x: 4 }}
      whileTap={{ scale: 0.98 }}
      className="bg-card border border-border rounded-2xl p-4 cursor-pointer hover:border-primary/50 hover:shadow-md transition-all group" 
      onClick={() => onClick(loan)}
    >
      <div className="flex justify-between items-start mb-2">
        <div>
          <p className="font-bold tracking-tight">{loan.clientName}</p>
          <p className="text-[10px] text-muted-foreground font-medium uppercase tracking-wider">{loan.frequency} • {loan.installmentsCount}x {formatCurrency(loan.installmentValue)}</p>
        </div>
        <ChevronRight className="h-4 w-4 text-muted-foreground group-hover:text-primary transition-colors" />
      </div>
      <div className="flex justify-between items-end">
        <p className="text-sm font-bold text-primary data-precision bg-primary/5 px-2 py-0.5 rounded-full">{formatCurrency(loan.totalAmount)}</p>
        <p className="text-[10px] text-muted-foreground italic editorial-accent">Início: {format(new Date(loan.startDate), 'dd/MM/yyyy')}</p>
      </div>
    </motion.div>
  );
});

const ClientCard = memo(({ client, onEdit, onDelete, onClick }: ClientCardProps) => {
  return (
    <motion.div 
      whileHover={{ y: -2 }}
      whileTap={{ scale: 0.98 }}
      className="bg-card border border-border rounded-2xl p-4 flex items-center justify-between cursor-pointer hover:border-primary/50 hover:shadow-md transition-all group" 
      onClick={() => onClick(client)}
    >
      <div className="flex items-center gap-3">
        <div className="h-12 w-12 rounded-full bg-secondary overflow-hidden border-2 border-transparent group-hover:border-primary/20 transition-all shadow-inner">
          {client.profilePhotoUrl ? (
            <img src={client.profilePhotoUrl} className="h-full w-full object-cover" referrerPolicy="no-referrer" />
          ) : (
            <div className="h-full w-full flex items-center justify-center text-muted-foreground opacity-40"><UserIcon className="h-6 w-6" /></div>
          )}
        </div>
        <div>
          <p className="font-bold tracking-tight">{client.name}</p>
          <p className="text-[10px] text-muted-foreground font-mono">{client.phone}</p>
        </div>
      </div>
      <div className="flex gap-1" onClick={e => e.stopPropagation()}>
        <button onClick={() => onEdit(client)} className="h-8 w-8 rounded-lg bg-secondary flex items-center justify-center hover:bg-primary hover:text-primary-foreground transition-all duration-300">
          <Pencil className="h-3.5 w-3.5" />
        </button>
        <AlertDialog>
          <AlertDialogTrigger asChild>
            <button className="h-8 w-8 rounded-lg bg-red-50 flex items-center justify-center hover:bg-red-500 hover:text-white transition-all duration-300">
              <Trash2 className="h-3.5 w-3.5" />
            </button>
          </AlertDialogTrigger>
          <AlertDialogContent className="rounded-3xl">
            <AlertDialogHeader>
              <AlertDialogTitle className="font-bold">Remover cliente?</AlertDialogTitle>
              <AlertDialogDescription>Isso removerá todos os dados e fotos associados.</AlertDialogDescription>
            </AlertDialogHeader>
            <AlertDialogFooter>
              <AlertDialogCancel variant="outline" className="rounded-xl">Cancelar</AlertDialogCancel>
              <AlertDialogAction variant="destructive" onClick={() => onDelete(client.id)} className="rounded-xl">Remover</AlertDialogAction>
            </AlertDialogFooter>
          </AlertDialogContent>
        </AlertDialog>
      </div>
    </motion.div>
  );
});

export default function App() {
  const [user, setUser] = useState<User | null>(null);
  const [userProfile, setUserProfile] = useState<UserProfile | null>(null);
  const [isAuthReady, setIsAuthReady] = useState(false);
  const [capitals, setCapitals] = useState<Capital[]>([]);
  const [generalCapital, setGeneralCapital] = useState<GeneralCapital | null>(null);
  const [loans, setLoans] = useState<Loan[]>([]);
  const [clients, setClients] = useState<Client[]>([]);
  const [withdrawals, setWithdrawals] = useState<Withdrawal[]>([]);
  const [appContributions, setAppContributions] = useState<AppContribution[]>([]);
  const [selectedLoan, setSelectedLoan] = useState<Loan | null>(null);
  const [selectedClient, setSelectedClient] = useState<Client | null>(null);
  const [allInstallments, setAllInstallments] = useState<Installment[]>([]);
  const [clientFiles, setClientFiles] = useState<ClientFile[]>([]);
  const [loading, setLoading] = useState(true);
  const [view, setView] = useState<'dashboard' | 'capitals' | 'loans' | 'clients' | 'withdrawals' | 'reports' | 'settings'>('dashboard');

  // --- Theme Application ---
  useEffect(() => {
    if (!userProfile?.theme) return;
    
    const applyTheme = (t: 'light' | 'dark' | 'system') => {
      const root = window.document.documentElement;
      root.classList.remove('light', 'dark');
      
      if (t === 'system') {
        const systemTheme = window.matchMedia('(prefers-color-scheme: dark)').matches ? 'dark' : 'light';
        root.classList.add(systemTheme);
      } else {
        root.classList.add(t);
      }
    };

    applyTheme(userProfile.theme);

    if (userProfile.theme === 'system') {
      const mediaQuery = window.matchMedia('(prefers-color-scheme: dark)');
      const handleChange = () => applyTheme('system');
      mediaQuery.addEventListener('change', handleChange);
      return () => mediaQuery.removeEventListener('change', handleChange);
    }
  }, [userProfile?.theme]);
  const [showForm, setShowForm] = useState(false);
  const [showAppContributionForm, setShowAppContributionForm] = useState(false);
  const [editingCapital, setEditingCapital] = useState<any>(null);
  const [editingClient, setEditingClient] = useState<Client | null>(null);
  const [pinModal, setPinModal] = useState<{ isOpen: boolean, onVerify: (p: string) => void } | null>(null);
  const [searchTerm, setSearchTerm] = useState("");

  const [isLocked, setIsLocked] = useState(true);

  // --- Auth Safety Timeouts ---
  // If Firebase doesn't respond in 6s on mobile, we force ready state
  useEffect(() => {
    const timer = setTimeout(() => {
      if (!isAuthReady) {
        console.warn("Auth initialization timed out, using fallback ready state.");
        setIsAuthReady(true);
      }
    }, 10000); // Increased to 10s to give mobile more time
    return () => clearTimeout(timer);
  }, [isAuthReady]);

  // Safety timeout for loading state
  useEffect(() => {
    if (isAuthReady && user) {
      const timer = setTimeout(() => {
        if (loading) {
          console.log("Data loading safety timeout triggered");
          setLoading(false);
        }
      }, 12000); // Increased to 12s for data sync
      return () => clearTimeout(timer);
    }
  }, [isAuthReady, loading, user]);

  // --- Auth & Profile ---
  useEffect(() => {
    // Check for redirect result on mount (crucial for mobile)
    getRedirectResult(auth).catch(err => {
      if (err.code !== 'auth/popup-closed-by-user') {
        console.error("Redirect Result Error:", err);
      }
    });

    const unsubscribe = onAuthStateChanged(auth, async (u) => {
      try {
        setUser(u);
        if (u) {
          const profileRef = doc(db, 'users', u.uid);
          const snap = await getDoc(profileRef);
          if (snap.exists()) {
            setUserProfile(snap.data() as UserProfile);
          } else {
            const newProfile: UserProfile = { uid: u.uid, email: u.email || "", notificationsEnabled: true, biometricsEnabled: false, theme: 'system' };
            await setDoc(profileRef, newProfile);
            setUserProfile(newProfile);
          }
        } else {
          setUserProfile(null);
        }
      } catch (err) {
        console.error("Auth initialization error:", err);
        toast.error("Erro ao carregar perfil de usuário.");
      } finally {
        setIsAuthReady(true);
      }
    });
    return () => unsubscribe();
  }, []);

  const handleUpdateProfile = useCallback(async (data: Partial<UserProfile>) => {
    if (!user) return;
    try {
      const profileRef = doc(db, 'users', user.uid);
      await updateDoc(profileRef, data);
      setUserProfile(p => p ? { ...p, ...data } : null);
    } catch (err) { handleFirestoreError(err, OperationType.UPDATE, 'users'); }
  }, [user]);

  const handleSetPin = useCallback(async (pin: string) => {
    if (!user) return;
    try {
      const profileRef = doc(db, 'users', user.uid);
      await updateDoc(profileRef, { pin });
      setUserProfile(p => p ? { ...p, pin } : null);
      toast.success("PIN configurado!");
    } catch (err) { handleFirestoreError(err, OperationType.UPDATE, 'users'); }
  }, [user]);

  const verifyPin = useCallback((action: () => void) => {
    if (!userProfile?.pin) {
      action();
      return;
    }
    setPinModal({
      isOpen: true,
      onVerify: (p) => {
        if (p === userProfile.pin) {
          action();
          setPinModal(null);
        } else {
          toast.error("PIN incorreto");
        }
      }
    });
  }, [userProfile]);

  async function handleLogin() {
    const provider = new GoogleAuthProvider();
    try {
      await signInWithPopup(auth, provider);
    } catch (error) {
      console.error("Login failed", error);
      toast.error("Falha no login.");
    }
  }

  useEffect(() => {
    if (!user || !selectedClient) {
      setClientFiles([]);
      return;
    }
    const q = query(collection(db, `clients/${selectedClient.id}/files`), where('uid', '==', user.uid));
    const unsub = onSnapshot(q, (snapshot) => {
      setClientFiles(snapshot.docs.map(doc => ({ id: doc.id, ...doc.data() } as ClientFile)));
    }, (err) => handleFirestoreError(err, OperationType.GET, 'client_files'));
    return () => unsub();
  }, [user, selectedClient]);

  async function handleLogout() {
    await signOut(auth);
  }

  // --- Data Fetching ---
  useEffect(() => {
    if (!isAuthReady || !user) {
      setCapitals([]);
      setLoans([]);
      setClients([]);
      setLoading(false);
      return;
    }

    setLoading(true);
    
    // Safety fallback: if anything fails or hangs, stop loading after 8 seconds
    const safetyTimer = setTimeout(() => {
      setLoading(false);
    }, 8000);

    const errorHandler = (err: any, type: OperationType, path: string) => {
      console.error(`Snapshot error (${path}):`, err);
      handleFirestoreError(err, type, path);
      // We don't necessarily set loading to false here to allow other listeners to try
    };

    const unsubGeneralCapital = onSnapshot(
      doc(db, 'general_capital', user.uid),
      (snap) => {
        if (snap.exists()) {
          setGeneralCapital(snap.data() as GeneralCapital);
        } else {
          setDoc(doc(db, 'general_capital', user.uid), { available_amount: 0, lent_amount: 0, profit: 0, uid: user.uid });
        }
      },
      (err) => errorHandler(err, OperationType.GET, 'general_capital')
    );

    const unsubCapitals = onSnapshot(
      query(collection(db, 'capitals'), where("uid", "==", user.uid), orderBy("created_date", "desc")),
      (snap) => setCapitals(snap.docs.map(d => ({ id: d.id, ...d.data() })) as Capital[]),
      (err) => errorHandler(err, OperationType.LIST, 'capitals')
    );

    const unsubLoans = onSnapshot(
      query(collection(db, 'loans'), where("uid", "==", user.uid), orderBy("created_date", "desc")),
      (snap) => setLoans(snap.docs.map(d => ({ id: d.id, ...d.data() })) as Loan[]),
      (err) => errorHandler(err, OperationType.LIST, 'loans')
    );

    const unsubClients = onSnapshot(
      query(collection(db, 'clients'), where("uid", "==", user.uid), orderBy("created_date", "desc")),
      (snap) => setClients(snap.docs.map(d => ({ id: d.id, ...d.data() })) as Client[]),
      (err) => errorHandler(err, OperationType.LIST, 'clients')
    );

    const unsubWithdrawals = onSnapshot(
      query(collection(db, 'withdrawals'), where("uid", "==", user.uid), orderBy("date", "desc")),
      (snap) => {
        setWithdrawals(snap.docs.map(d => ({ id: d.id, ...d.data() })) as Withdrawal[]);
        setLoading(false);
      },
      (err) => {
        errorHandler(err, OperationType.LIST, 'withdrawals');
        setLoading(false);
      }
    );

    const unsubAppContributions = onSnapshot(
      query(collection(db, 'app_contributions'), where("uid", "==", user.uid), orderBy("date", "desc")),
      (snap) => setAppContributions(snap.docs.map(d => ({ id: d.id, ...d.data() })) as AppContribution[]),
      (err) => errorHandler(err, OperationType.LIST, 'app_contributions')
    );

    const unsubInstallments = onSnapshot(
      query(collectionGroup(db, 'installments'), where("uid", "==", user.uid)),
      (snap) => {
        const data = snap.docs.map(d => ({ id: d.id, ...d.data() })) as Installment[];
        const today = startOfDay(new Date());
        const updated = data.map(i => {
          if (i.status === 'pending' && isBefore(new Date(i.dueDate), today)) {
            return { ...i, status: 'overdue' as const };
          }
          return i;
        });
        setAllInstallments(updated);
      },
      (err) => errorHandler(err, OperationType.LIST, 'installments')
    );

    return () => { 
      clearTimeout(safetyTimer);
      unsubGeneralCapital(); 
      unsubCapitals(); 
      unsubLoans(); 
      unsubClients(); 
      unsubWithdrawals(); 
      unsubAppContributions();
      unsubInstallments();
    };
  }, [isAuthReady, user]);

  // --- Derived State ---
  const installments = useMemo(() => {
    if (!selectedLoan) return [];
    return allInstallments.filter(i => i.loanId === selectedLoan.id).sort((a, b) => a.number - b.number);
  }, [allInstallments, selectedLoan]);
  const derivedGeneralCapital = useMemo(() => {
    if (!generalCapital) return null;

    const totalAportes = appContributions.reduce((s, c) => s + c.amount, 0);
    const totalCapitaisIndividuais = capitals.reduce((s, c) => s + c.balance, 0);
    const totalRecebimentos = loans.reduce((s, l) => s + (l.amountPaid || 0), 0);
    const totalEmprestimosAtivos = loans.filter(l => l.status === 'active').reduce((s, l) => s + l.amount, 0);
    const totalRetiradas = withdrawals.reduce((s, w) => s + w.amount, 0);

    const available = (totalAportes + totalCapitaisIndividuais + totalRecebimentos) - (totalEmprestimosAtivos + totalRetiradas);
    
    const lent = loans.filter(l => l.status === 'active').reduce((s, l) => {
      const principalRatio = l.amount / l.totalAmount;
      const paidAmount = l.amountPaid || 0;
      const paidPrincipal = paidAmount * principalRatio;
      return s + (l.amount - paidPrincipal);
    }, 0);

    const profit = loans.reduce((s, l) => {
      const principalRatio = l.amount / l.totalAmount;
      const paidAmount = l.amountPaid || 0;
      const interestPart = paidAmount * (1 - principalRatio);
      return s + interestPart;
    }, 0);

    return {
      ...generalCapital,
      available_amount: available,
      lent_amount: lent,
      profit: profit
    };
  }, [generalCapital, appContributions, capitals, loans, withdrawals]);

  // Sync derived capital to Firestore
  useEffect(() => {
    if (user && derivedGeneralCapital && generalCapital) {
      const diffAvailable = Math.abs(derivedGeneralCapital.available_amount - generalCapital.available_amount);
      const diffLent = Math.abs(derivedGeneralCapital.lent_amount - generalCapital.lent_amount);
      const diffProfit = Math.abs(derivedGeneralCapital.profit - generalCapital.profit);
      
      if (diffAvailable > 0.01 || diffLent > 0.01 || diffProfit > 0.01) {
        const genRef = doc(db, 'general_capital', user.uid);
        updateDoc(genRef, {
          available_amount: derivedGeneralCapital.available_amount,
          lent_amount: derivedGeneralCapital.lent_amount,
          profit: derivedGeneralCapital.profit
        }).catch(err => console.error("Error syncing capital:", err));
      }
    }
  }, [derivedGeneralCapital, generalCapital, user]);

  // --- Actions ---
  const handleSaveAppContribution = useCallback(async (data: any) => {
    if (!user || !generalCapital) return;
    const batch = writeBatch(db);
    try {
      const contributionRef = doc(collection(db, 'app_contributions'));
      batch.set(contributionRef, {
        ...data,
        uid: user.uid,
        created_date: new Date().toISOString()
      });

      const genCapRef = doc(db, 'general_capital', user.uid);
      batch.update(genCapRef, {
        available_amount: increment(data.amount)
      });

      // Log the contribution
      const logRef = doc(collection(db, 'logs'));
      batch.set(logRef, {
        action: 'Aporte adicionado',
        date: new Date().toISOString(),
        userEmail: user.email,
        details: `Aporte direto de ${formatCurrency(data.amount)} ao Capital do App.`,
        uid: user.uid
      });

      await batch.commit();
      setShowAppContributionForm(false);
      toast.success("Aporte ao Capital do App realizado!");
    } catch (err) { handleFirestoreError(err, OperationType.WRITE, 'app_contributions'); }
  }, [user, generalCapital]);

  const handleDeleteAppContribution = useCallback(async (id: string) => {
    verifyPin(async () => {
      if (!user || !generalCapital) return;
      const contribution = appContributions.find(c => c.id === id);
      if (!contribution) return;

      const batch = writeBatch(db);
      try {
        const contributionRef = doc(db, 'app_contributions', id);
        const genCapRef = doc(db, 'general_capital', user.uid);

        batch.delete(contributionRef);
        batch.update(genCapRef, {
          available_amount: increment(-contribution.amount)
        });

        // Log the removal
        const logRef = doc(collection(db, 'logs'));
        batch.set(logRef, {
          action: 'Aporte removido',
          date: new Date().toISOString(),
          userEmail: user.email,
          details: `Aporte direto de ${formatCurrency(contribution.amount)} removido do Capital do App.`,
          uid: user.uid
        });

        await batch.commit();
        toast.success("Aporte removido com sucesso!");
      } catch (err) { handleFirestoreError(err, OperationType.DELETE, 'app_contributions'); }
    });
  }, [user, generalCapital, appContributions, verifyPin]);

  async function handleSaveCapital(data: any) {
    if (!user || !generalCapital) return;
    const batch = writeBatch(db);
    try {
      if (editingCapital) {
        const diff = data.balance - editingCapital.balance;
        const capRef = doc(db, 'capitals', editingCapital.id);
        const genRef = doc(db, 'general_capital', user.uid);
        
        batch.update(capRef, data);
        batch.update(genRef, {
          available_amount: generalCapital.available_amount + diff
        });
        
        await batch.commit();
        toast.success("Capital atualizado!");
        setEditingCapital(null);
      } else {
        const capRef = doc(collection(db, 'capitals'));
        const genRef = doc(db, 'general_capital', user.uid);
        
        batch.set(capRef, { ...data, uid: user.uid, created_date: new Date().toISOString() });
        batch.update(genRef, {
          available_amount: generalCapital.available_amount + data.balance
        });
        
        await batch.commit();
        toast.success("Capital cadastrado!");
        setShowForm(false);
      }
    } catch (err) { handleFirestoreError(err, OperationType.WRITE, 'capitals'); }
  }

  async function handleDeleteCapital(id: string) {
    verifyPin(async () => {
      if (!user || !generalCapital) return;
      const capital = capitals.find(c => c.id === id);
      if (!capital) return;

      const batch = writeBatch(db);
      try {
        const capRef = doc(db, 'capitals', id);
        const genRef = doc(db, 'general_capital', user.uid);

        batch.delete(capRef);
        batch.update(genRef, {
          available_amount: Math.max(0, generalCapital.available_amount - capital.balance)
        });

        await batch.commit();
        toast.success("Capital removido com sucesso!");
      } catch (err) { handleFirestoreError(err, OperationType.DELETE, 'capitals'); }
    });
  }

  async function handleSaveLoan(data: any) {
    if (!user) return;
    const batch = writeBatch(db);
    try {
      // 1. Create Loan
      const loanRef = doc(collection(db, 'loans'));
      const { clientId, ...rest } = data;
      const loanData = {
        ...rest,
        clientId: clientId === 'none' ? null : clientId,
        amountPaid: 0,
        uid: user.uid,
        created_date: new Date().toISOString()
      };
      batch.set(loanRef, loanData);

      // 2. Generate Installments
      const insts = generateInstallments(
        data.totalAmount,
        data.installmentsCount,
        data.frequency,
        new Date(data.startDate),
        { includeSundays: data.includeSundays, paymentDay: data.paymentDay }
      );

      insts.forEach(i => {
        const instRef = doc(collection(db, `loans/${loanRef.id}/installments`));
        batch.set(instRef, {
          ...i,
          dueDate: i.dueDate.toISOString(),
          loanId: loanRef.id,
          uid: user.uid
        });
      });

      // 3. Update General Capital
      if (generalCapital) {
        const genRef = doc(db, 'general_capital', user.uid);
        batch.update(genRef, {
          available_amount: generalCapital.available_amount - data.amount,
          lent_amount: (generalCapital.lent_amount || 0) + data.amount
        });
      }

      await batch.commit();
      toast.success("Empréstimo gerado com sucesso!");
      setShowForm(false);
      setView('loans');
    } catch (err) { handleFirestoreError(err, OperationType.WRITE, 'loans'); }
  }

  async function handleUpdateInstallment(inst: Installment, status: any) {
    verifyPin(async () => {
      if (!selectedLoan || !user || !generalCapital) return;
      const batch = writeBatch(db);
      try {
        const instRef = doc(db, `loans/${selectedLoan.id}/installments`, inst.id);
        const genRef = doc(db, 'general_capital', user.uid);

        batch.update(instRef, { 
          status, 
          paidDate: status === 'paid' ? new Date().toISOString() : null 
        });

        const loanRef = doc(db, 'loans', selectedLoan.id);
        if (status === 'paid' && inst.status !== 'paid') {
          // Calculate principal and interest
          const principalRatio = selectedLoan.amount / selectedLoan.totalAmount;
          const principalPart = inst.amount * principalRatio;
          const interestPart = inst.amount - principalPart;

          batch.update(loanRef, {
            amountPaid: increment(inst.amount)
          });

          batch.update(genRef, {
            available_amount: generalCapital.available_amount + inst.amount,
            lent_amount: Math.max(0, generalCapital.lent_amount - principalPart),
            profit: generalCapital.profit + interestPart
          });
        } else if (status !== 'paid' && inst.status === 'paid') {
          // Revert payment
          const principalRatio = selectedLoan.amount / selectedLoan.totalAmount;
          const principalPart = inst.amount * principalRatio;
          const interestPart = inst.amount - principalPart;

          batch.update(loanRef, {
            amountPaid: increment(-inst.amount)
          });

          batch.update(genRef, {
            available_amount: Math.max(0, generalCapital.available_amount - inst.amount),
            lent_amount: generalCapital.lent_amount + principalPart,
            profit: Math.max(0, generalCapital.profit - interestPart)
          });
        }

        await batch.commit();
        toast.success("Parcela atualizada!");
      } catch (err) { handleFirestoreError(err, OperationType.UPDATE, 'installments'); }
    });
  }

  async function handleCancelLoan(loan: Loan) {
    verifyPin(async () => {
      if (!user || !generalCapital) return;
      const batch = writeBatch(db);
      try {
        const loanRef = doc(db, 'loans', loan.id);
        const genRef = doc(db, 'general_capital', user.uid);

        // 1. Mark loan as cancelled
        batch.update(loanRef, { status: 'cancelled' });

        // 2. Calculate remaining principal to return
        // We need to fetch installments to be accurate, but we can also estimate or just use the current lent_amount logic
        // Actually, since we are in a batch and we want to be safe, let's just use the loan.amount and subtract what was already paid
        const principalRatio = loan.amount / loan.totalAmount;
        const paidAmount = installments.filter(i => i.status === 'paid').reduce((s, i) => s + i.amount, 0);
        const paidPrincipal = paidAmount * principalRatio;
        const remainingPrincipal = loan.amount - paidPrincipal;

        batch.update(genRef, {
          available_amount: generalCapital.available_amount + remainingPrincipal,
          lent_amount: Math.max(0, generalCapital.lent_amount - remainingPrincipal)
        });

        // 3. Log action
        const logRef = doc(collection(db, 'logs'));
        batch.set(logRef, {
          action: "Empréstimo excluído",
          date: new Date().toISOString(),
          userEmail: user.email,
          details: `Empréstimo de ${loan.clientName} no valor de ${formatCurrency(loan.amount)} cancelado.`,
          uid: user.uid
        });

        await batch.commit();
        setSelectedLoan(null);
        toast.success("Empréstimo cancelado e capital estornado.");
      } catch (err) { handleFirestoreError(err, OperationType.UPDATE, 'loans'); }
    });
  }

  async function handleSaveClient(data: any, pendingFiles?: PendingFile[]) {
    if (!user) return;
    try {
      let clientId = editingClient?.id;
      if (editingClient) {
        await updateDoc(doc(db, 'clients', editingClient.id), data);
        toast.success("Cliente atualizado!");
        setEditingClient(null);
      } else {
        const docRef = await addDoc(collection(db, 'clients'), { 
          ...data, 
          uid: user.uid, 
          created_date: new Date().toISOString(),
          photos: [],
          faceRegistered: false
        });
        clientId = docRef.id;
        toast.success("Cliente cadastrado!");
        setShowForm(false);
      }

      if (pendingFiles && pendingFiles.length > 0 && clientId) {
        toast.info("Fazendo upload dos arquivos...");
        for (const pf of pendingFiles) {
          const path = `clients/${clientId}/${pf.type}_${Date.now()}_${pf.file.name}`;
          const url = await uploadImage(pf.file, path);
          
          if (pf.type === 'photo') {
            const clientRef = doc(db, 'clients', clientId);
            await updateDoc(clientRef, {
              photos: arrayUnion(url)
            });
          } else {
            await addDoc(collection(db, `clients/${clientId}/files`), {
              type: pf.category || 'Outros',
              category: 'Documentos',
              url,
              uid: user.uid,
              uploadDate: new Date().toISOString()
            });
          }
        }
        toast.success("Uploads concluídos!");
      }
    } catch (err) { handleFirestoreError(err, OperationType.WRITE, 'clients'); }
  }

  async function handleSaveClientFile(clientId: string, data: any) {
    if (!user) return;
    try {
      await addDoc(collection(db, `clients/${clientId}/files`), {
        ...data,
        uid: user.uid,
        uploadDate: new Date().toISOString()
      });
      toast.success("Arquivo salvo!");
    } catch (err) { handleFirestoreError(err, OperationType.WRITE, 'client_files'); }
  }

  async function handleDeleteClientFile(clientId: string, fileId: string) {
    try {
      await deleteDoc(doc(db, `clients/${clientId}/files`, fileId));
      toast.success("Arquivo removido.");
    } catch (err) { handleFirestoreError(err, OperationType.DELETE, 'client_files'); }
  }

  async function handleUpdateClient(id: string, data: any) {
    try {
      await updateDoc(doc(db, 'clients', id), data);
    } catch (err) { handleFirestoreError(err, OperationType.UPDATE, 'clients'); }
  }

  async function handleDeleteClient(id: string) {
    try {
      await deleteDoc(doc(db, 'clients', id));
      toast.success("Cliente removido.");
    } catch (err) { handleFirestoreError(err, OperationType.DELETE, 'clients'); }
  }

  async function handleSaveWithdrawal(data: any) {
    if (!user) return;
    
    setPinModal({
      isOpen: true,
      onVerify: async (pin) => {
        if (pin !== userProfile?.pin) {
          toast.error("PIN incorreto.");
          return;
        }
        
        try {
          const batch = writeBatch(db);
          const withdrawalRef = doc(collection(db, 'withdrawals'));
          const genRef = doc(db, 'general_capital', user.uid);

          if (!generalCapital) return;

          batch.set(withdrawalRef, {
            ...data,
            uid: user.uid,
            created_date: new Date().toISOString()
          });

          if (data.capitalId !== 'app') {
            const capitalRef = doc(db, 'capitals', data.capitalId);
            const selectedCapital = capitals.find(c => c.id === data.capitalId);
            if (selectedCapital) {
              batch.update(capitalRef, {
                balance: selectedCapital.balance - data.amount
              });
            }
          }

          batch.update(genRef, {
            available_amount: generalCapital.available_amount - data.amount
          });

          await batch.commit();
          toast.success("Retirada registrada com sucesso.");
          setShowForm(false);
          setPinModal(null);
        } catch (err) {
          handleFirestoreError(err, OperationType.WRITE, 'withdrawals');
        }
      }
    });
  }

  console.log("App State:", { isAuthReady, user: !!user, hasProfile: !!userProfile, hasPin: !!userProfile?.pin, isLocked, loading });

  const filteredClients = clients.filter(c => c.name.toLowerCase().includes(searchTerm.toLowerCase()));

  return (
    <div className="min-h-screen min-h-[100dvh] bg-background max-w-md mx-auto border-x border-border relative overflow-hidden flex flex-col">
      <Toaster position="top-center" expand={true} richColors />
      <AnimatePresence mode="wait">
        {(!isAuthReady || loading) ? (
          <motion.div 
            key="skeleton"
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0, scale: 0.95 }}
            transition={{ duration: 0.4, ease: "easeInOut" }}
            className="p-6 space-y-6"
          >
            <div className="flex justify-between items-center">
              <Skeleton className="h-8 w-32" />
              <Skeleton className="h-10 w-10 rounded-full" />
            </div>
            <div className="grid grid-cols-2 gap-4">
              <Skeleton className="h-24 rounded-3xl" />
              <Skeleton className="h-24 rounded-3xl" />
            </div>
            <Skeleton className="h-12 rounded-2xl w-full" />
            <div className="grid grid-cols-3 gap-3">
              <Skeleton className="h-16 rounded-2xl" />
              <Skeleton className="h-16 rounded-2xl" />
              <Skeleton className="h-16 rounded-2xl" />
            </div>
            <div className="space-y-3">
              <Skeleton className="h-4 w-24" />
              <Skeleton className="h-20 rounded-2xl w-full" />
              <Skeleton className="h-20 rounded-2xl w-full" />
            </div>
            
            <p className="text-[11px] text-center text-muted-foreground animate-pulse pt-4">
              Verificando sua conta e sincronizando capitais...
            </p>
          </motion.div>
        ) : !user ? (
          <motion.div
            key="auth"
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0, y: -20 }}
            transition={{ duration: 0.5, ease: "easeInOut" }}
          >
            <AuthScreen onLogin={() => {}} />
          </motion.div>
        ) : (userProfile && !userProfile.pin) ? (
          <motion.div
            key="create-pin"
            initial={{ opacity: 0, x: 100 }}
            animate={{ opacity: 1, x: 0 }}
            exit={{ opacity: 0, x: -100 }}
            transition={{ type: "spring", stiffness: 300, damping: 30 }}
          >
            <CreatePinScreen 
              onSetPin={(pin) => {
                handleSetPin(pin);
                setIsLocked(false);
              }} 
            />
          </motion.div>
        ) : (userProfile && userProfile.pin && isLocked) ? (
          <motion.div
            key="lock"
            initial={{ opacity: 0, scale: 1.1 }}
            animate={{ opacity: 1, scale: 1 }}
            exit={{ opacity: 0, scale: 0.9 }}
            transition={{ duration: 0.4 }}
          >
            <LockScreen 
              profile={userProfile} 
              onUnlock={() => setIsLocked(false)} 
            />
          </motion.div>
        ) : (
          <motion.div
            key="main"
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            className="relative h-full"
          >
      
      {pinModal && <PinModal 
        isOpen={pinModal.isOpen} 
        onVerify={pinModal.onVerify} 
        onCancel={() => setPinModal(null)} 
        length={userProfile?.pin?.length || 4}
      />}

      <div className="flex justify-between items-center p-4">
        <div className="flex items-center gap-2">
          <Button variant="ghost" size="icon" onClick={() => setView('settings')} className="rounded-xl">
            <Settings className="h-5 w-5 text-muted-foreground" />
          </Button>
          <div className="flex items-center gap-2">
            <div className="h-8 w-8 bg-primary rounded-lg flex items-center justify-center"><Wallet className="h-4 w-4 text-primary-foreground" /></div>
            <span className="font-bold">Capital Flow</span>
          </div>
        </div>
        <div className="flex items-center gap-2">
          <Button variant="ghost" size="icon" onClick={() => setIsLocked(true)} className="rounded-xl text-muted-foreground">
            <Lock className="h-4 w-4" />
          </Button>
          <div className="h-8 w-8 rounded-full bg-secondary overflow-hidden border border-border">
            {userProfile?.photoURL ? (
              <img src={userProfile.photoURL} alt="User" className="h-full w-full object-cover" referrerPolicy="no-referrer" />
            ) : (
              <div className="h-full w-full flex items-center justify-center text-muted-foreground">
                <UserIcon className="h-4 w-4" />
              </div>
            )}
          </div>
        </div>
      </div>

      <ScrollArea className="h-[calc(100vh-140px)]">
        {selectedLoan ? (
          <div className="px-5">
            <LoanDetails 
              loan={selectedLoan} 
              installments={installments} 
              onUpdateInstallment={handleUpdateInstallment}
              onCancelLoan={handleCancelLoan}
              onBack={() => setSelectedLoan(null)}
            />
          </div>
        ) : selectedClient ? (
          <div className="px-5">
            <ClientDetails 
              client={selectedClient} 
              files={clientFiles}
              loans={loans}
              onAddFile={handleSaveClientFile}
              onDeleteFile={handleDeleteClientFile}
              onUpdate={handleUpdateClient}
              onBack={() => setSelectedClient(null)}
            />
          </div>
        ) : (
          <>
            <PageHeader 
              title={view === 'dashboard' ? "Dashboard" : view === 'capitals' ? "Capitais" : view === 'loans' ? "Empréstimos" : view === 'clients' ? "Clientes" : view === 'withdrawals' ? "Retiradas" : "Relatórios"} 
              subtitle={view === 'dashboard' ? "Visão Geral" : view === 'capitals' ? `${capitals.length} cadastrados` : view === 'loans' ? `${loans.length} ativos` : view === 'clients' ? `${clients.length} cadastrados` : view === 'withdrawals' ? `${withdrawals.length} registros` : "Análise Financeira"} 
              action={
                (view !== 'dashboard' && view !== 'reports') && (
                  <Button size="sm" className="rounded-xl gap-1" onClick={() => setShowForm(true)}>
                    <Plus className="h-4 w-4" /> Novo
                  </Button>
                )
              } 
            />

            <div className="px-5 py-4 space-y-4">
              {view === 'settings' && (
                <SettingsScreen 
                  user={user} 
                  userProfile={userProfile} 
                  onUpdateProfile={handleUpdateProfile} 
                  onLogout={handleLogout}
                  onBack={() => setView('dashboard')}
                  onOpenPinModal={(onVerify) => setPinModal({ isOpen: true, onVerify })}
                  onSetPin={handleSetPin}
                />
              )}

              {view === 'dashboard' && (
                <Dashboard 
                  loans={loans} 
                  clients={clients} 
                  installments={allInstallments} 
                  withdrawals={withdrawals} 
                  capitals={capitals} 
                  generalCapital={derivedGeneralCapital} 
                  userProfile={userProfile} 
                  onUpdateProfile={handleUpdateProfile}
                  appContributions={appContributions}
                />
              )}
              
              {view === 'reports' && <Reports loans={loans} clients={clients} installments={allInstallments} withdrawals={withdrawals} capitals={capitals} generalCapital={derivedGeneralCapital} appContributions={appContributions} />}

              {view === 'clients' && (
                <div className="relative">
                  <Search className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground" />
                  <Input 
                    placeholder="Buscar cliente..." 
                    className="pl-9 rounded-xl" 
                    value={searchTerm} 
                    onChange={e => setSearchTerm(e.target.value)} 
                  />
                </div>
              )}

              {showForm && view === 'capitals' && (
                <CapitalForm onSave={handleSaveCapital} onCancel={() => setShowForm(false)} />
              )}

              {showForm && view === 'loans' && (
                <LoanForm capitals={capitals} clients={clients} onSave={handleSaveLoan} onCancel={() => setShowForm(false)} generalCapital={derivedGeneralCapital} />
              )}

              {showForm && view === 'clients' && (
                <ClientForm onSave={handleSaveClient} onCancel={() => setShowForm(false)} />
              )}

              {showForm && view === 'withdrawals' && (
                <WithdrawalForm capitals={capitals} onSave={handleSaveWithdrawal} onCancel={() => setShowForm(false)} generalCapital={derivedGeneralCapital} />
              )}
              
              {showAppContributionForm && (
                <AppContributionForm onSave={handleSaveAppContribution} onCancel={() => setShowAppContributionForm(false)} />
              )}

              {view === 'capitals' ? (
                <div className="space-y-3">
                  <Button 
                    onClick={() => setShowAppContributionForm(true)}
                    className="w-full h-12 rounded-2xl bg-emerald-600 hover:bg-emerald-700 text-white font-bold gap-2 shadow-sm mb-2"
                  >
                    <PlusCircle className="h-5 w-5" /> Adicionar ao Capital do App
                  </Button>

                  <div className="space-y-3 mb-6">
                    <p className="text-xs font-bold text-muted-foreground uppercase px-1">Aportes Diretos (Capital App)</p>
                    <div className="bg-card border border-border rounded-3xl overflow-hidden">
                      <div className="p-4 bg-emerald-50/50 border-b border-border flex justify-between items-center">
                        <p className="text-xs font-bold text-emerald-700">Total de Aportes Diretos</p>
                        <p className="text-sm font-bold text-emerald-700">{formatCurrency(appContributions.reduce((s, c) => s + c.amount, 0))}</p>
                      </div>
                      <div className="divide-y divide-border max-h-60 overflow-y-auto">
                        {appContributions.length > 0 ? appContributions.map(c => (
                          <div key={c.id} className="p-3 flex justify-between items-center group">
                            <div>
                              <p className="text-xs font-bold">{c.description || "Aporte direto"}</p>
                              <p className="text-[10px] text-muted-foreground">{format(new Date(c.date), 'dd/MM/yyyy')}</p>
                            </div>
                            <div className="flex items-center gap-3">
                              <p className="text-xs font-bold text-emerald-600">+{formatCurrency(c.amount)}</p>
                              <AlertDialog>
                                <AlertDialogTrigger asChild>
                                <button className="h-7 w-7 rounded-lg bg-red-50 flex items-center justify-center hover:bg-red-100 transition-colors opacity-0 group-hover:opacity-100">
                                  <Trash2 className="h-3 w-3 text-red-500" />
                                </button>
                              </AlertDialogTrigger>
                                <AlertDialogContent>
                                  <AlertDialogHeader>
                                    <AlertDialogTitle>Remover aporte?</AlertDialogTitle>
                                    <AlertDialogDescription>Tem certeza que deseja remover este aporte? O valor será subtraído do capital disponível.</AlertDialogDescription>
                                  </AlertDialogHeader>
                                  <AlertDialogFooter>
                                    <AlertDialogCancel variant="outline">Cancelar</AlertDialogCancel>
                                    <AlertDialogAction variant="destructive" onClick={() => handleDeleteAppContribution(c.id)}>Remover</AlertDialogAction>
                                  </AlertDialogFooter>
                                </AlertDialogContent>
                              </AlertDialog>
                            </div>
                          </div>
                        )) : (
                          <div className="p-4 text-center text-[10px] text-muted-foreground italic">Nenhum aporte direto registrado</div>
                        )}
                      </div>
                    </div>
                  </div>

                  <p className="text-xs font-bold text-muted-foreground uppercase px-1">Saldos Individuais</p>
                  {capitals.map(cap => (
                    editingCapital?.id === cap.id ? (
                      <CapitalForm key={cap.id} initial={cap} onSave={handleSaveCapital} onCancel={() => setEditingCapital(null)} />
                    ) : (
                      <CapitalCard key={cap.id} capital={cap} onEdit={setEditingCapital} onDelete={handleDeleteCapital} />
                    )
                  ))}
                </div>
              ) : view === 'loans' ? (
                <div className="space-y-3">
                  {loans.filter(l => l.status !== 'cancelled').map(loan => (
                    <LoanCard key={loan.id} loan={loan} onClick={setSelectedLoan} />
                  ))}
                </div>
              ) : view === 'clients' ? (
                <div className="space-y-3">
                  {filteredClients.map(client => (
                    editingClient?.id === client.id ? (
                      <ClientForm key={client.id} initial={client} onSave={handleSaveClient} onCancel={() => setEditingClient(null)} />
                    ) : (
                      <ClientCard key={client.id} client={client} onEdit={setEditingClient} onDelete={handleDeleteClient} onClick={setSelectedClient} />
                    )
                  ))}
                </div>
              ) : view === 'withdrawals' ? (
                <div className="space-y-3">
                  {withdrawals.map(w => (
                    <WithdrawalCard key={w.id} withdrawal={w} capitalName={capitals.find(c => c.id === w.capitalId)?.name || "Desconhecido"} />
                  ))}
                  {withdrawals.length === 0 && (
                    <div className="py-12 text-center bg-muted/20 rounded-3xl border-2 border-dashed border-border">
                      <LogOut className="h-10 w-10 text-muted-foreground mx-auto mb-3 opacity-20 rotate-90" />
                      <p className="text-sm text-muted-foreground">Nenhuma retirada registrada</p>
                    </div>
                  )}
                </div>
              ) : null}
            </div>
          </>
        )}
      </ScrollArea>

      {/* Bottom Nav */}
      {(!selectedLoan && !selectedClient) && (
        <div className="fixed bottom-0 left-0 right-0 max-w-md mx-auto bg-background/80 backdrop-blur-md border-t border-border px-6 py-4 pb-7 flex justify-between items-center z-50 shadow-lg">
          <button onClick={() => {setView('dashboard'); setSelectedLoan(null); setSelectedClient(null);}} className={`flex flex-col items-center gap-1 transition-all ${view === 'dashboard' ? 'text-primary scale-110' : 'text-muted-foreground hover:text-primary/70'}`}>
            <TrendingUp className="h-5 w-5" />
            <span className="text-[10px] font-bold">Início</span>
          </button>
          <button onClick={() => {setView('capitals'); setSelectedLoan(null); setSelectedClient(null);}} className={`flex flex-col items-center gap-1 ${view === 'capitals' ? 'text-primary' : 'text-muted-foreground'}`}>
            <Wallet className="h-5 w-5" />
            <span className="text-[10px] font-bold">Capitais</span>
          </button>
          <button onClick={() => {setView('loans'); setSelectedLoan(null); setSelectedClient(null);}} className={`flex flex-col items-center gap-1 ${view === 'loans' ? 'text-primary' : 'text-muted-foreground'}`}>
            <HandCoins className="h-5 w-5" />
            <span className="text-[10px] font-bold">Empréstimos</span>
          </button>
          <button onClick={() => {setView('clients'); setSelectedLoan(null); setSelectedClient(null);}} className={`flex flex-col items-center gap-1 ${view === 'clients' ? 'text-primary' : 'text-muted-foreground'}`}>
            <Users className="h-5 w-5" />
            <span className="text-[10px] font-bold">Clientes</span>
          </button>
          <button onClick={() => {setView('reports'); setSelectedLoan(null); setSelectedClient(null);}} className={`flex flex-col items-center gap-1 ${view === 'reports' ? 'text-primary' : 'text-muted-foreground'}`}>
            <BarChart3 className="h-5 w-5" />
            <span className="text-[10px] font-bold">Relatórios</span>
          </button>
          <button onClick={() => {setView('withdrawals'); setSelectedLoan(null); setSelectedClient(null);}} className={`flex flex-col items-center gap-1 ${view === 'withdrawals' ? 'text-primary' : 'text-muted-foreground'}`}>
            <LogOut className="h-5 w-5 rotate-90" />
            <span className="text-[10px] font-bold">Retiradas</span>
          </button>
        </div>
      )}
        </motion.div>
        )}
      </AnimatePresence>
    </div>
  );
}
