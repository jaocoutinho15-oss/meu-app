import { initializeApp } from 'firebase/app';
import { getAuth } from 'firebase/auth';
import { getFirestore } from 'firebase/firestore';
import { getStorage } from 'firebase/storage';

// Direct import of config (Vite handles this)
import aiStudioConfig from '../firebase-applet-config.json';

// Helper to check if a value is a real Firebase API Key (starts with AIza)
const isRealKey = (val?: any): val is string => typeof val === 'string' && val.startsWith('AIza') && val.length > 20;

const env = import.meta.env;

const firebaseConfig = {
  apiKey: isRealKey(aiStudioConfig?.apiKey) ? aiStudioConfig.apiKey : (isRealKey(env.VITE_FIREBASE_API_KEY) ? env.VITE_FIREBASE_API_KEY : undefined),
  authDomain: aiStudioConfig?.authDomain || env.VITE_FIREBASE_AUTH_DOMAIN,
  projectId: aiStudioConfig?.projectId || env.VITE_FIREBASE_PROJECT_ID,
  storageBucket: aiStudioConfig?.storageBucket || env.VITE_FIREBASE_STORAGE_BUCKET,
  messagingSenderId: aiStudioConfig?.messagingSenderId || env.VITE_FIREBASE_MESSAGING_SENDER_ID,
  appId: aiStudioConfig?.appId || env.VITE_FIREBASE_APP_ID,
  firestoreDatabaseId: aiStudioConfig?.firestoreDatabaseId || env.VITE_FIREBASE_DATABASE_ID || '(default)'
};

console.log("Firebase Init Details:", {
  apiKey: firebaseConfig.apiKey ? (firebaseConfig.apiKey.slice(0, 5) + "...") : "MISSING",
  projectId: firebaseConfig.projectId,
  dbId: firebaseConfig.firestoreDatabaseId
});

let app;
try {
  app = initializeApp(firebaseConfig);
  console.log("Firebase initialized successfully");
} catch (error) {
  console.error("Firebase Initialization Failed:", error);
  // Create a dummy app to prevent crashes, though it won't work correctly
  app = initializeApp({ apiKey: "invalid", authDomain: "invalid", projectId: "invalid" });
}

export const db = getFirestore(app, firebaseConfig.firestoreDatabaseId === '(default)' ? undefined : firebaseConfig.firestoreDatabaseId);
export const auth = getAuth(app);
export const storage = getStorage(app);
